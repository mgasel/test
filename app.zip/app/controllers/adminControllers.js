
const md5=require('md5');
const async=require('async');
const Admin=require('../models/Admin.js');
const AppConstraints=require('../../config/appConstraints.js');
const UnivershalFunction=require('../UnivershalFunctions/Univershalfunctions.js');
const jwt=require('jsonwebtoken');
const User=require('../models/User.js');
const Service=require('../models/Services.js');
const Forgot=require('../models/Forgot.js');
const Driver=require('../models/User.js');
const Laundry=require('../models/Laundry.js');
const NodeGeocoder = require('node-geocoder');
const randomstring=require('randomstring');
const serviceItem=require('../models/serviceItems.js');
const SubscriptionPlane=require('../models/SubscriptionsPlan.js');
const SubscriptionPlaneItem=require('../models/SubcriptionPlaneItems.js');
const Bookings=require('../models/Bookings.js');
const NotificationData=require('../models/notification.js');
const PromoCode=require('../models/promoCode.js');
const coupon = require('../models/coupon.js');
const pushNotification=require('../LIB/pushNotification.js');
const Review=require('../models/reviews.js');
const Vehicle=require('../models/Vehicle.js');
const SocketManager=require('../LIB/SocketManager.js');
const Charge=require('../models/charge.js');
const Issue=require('../models/issue');
const slots=require('../models/slots');
const ObjectId = require('mongodb').ObjectID;
const version = require('../models/Version');
exports.loginAdmin=async(request,response)=>{
  try{
      request.checkBody('email',AppConstraints.EMAIL_ADDRESS).notEmpty();
      request.checkBody('email',AppConstraints.VALID_EMAIL_ADDRESS).isEmail();
      request.checkBody('password',AppConstraints.PASSWORD).notEmpty();
      let errors = await request.validationErrors();
      if (errors)
      return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});

      let isAdmin=await Admin.findOne({email:request.body.email,password:md5(request.body.password)});
      if(!isAdmin)
      return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.INVALID_EMAIL_PASSWORD});
      let payloadData={
          email:request.body.email,
          password:request.body.password,
          exp: Math.floor(Date.now() / 1000) + (60 * 60*60)
      }
      let createToken=await jwt.sign(payloadData,process.env.JWT_SECRET);
      await Admin.update({email:request.body.email,password:md5(request.body.password)},{$set:{accessToken:createToken}});
      let criteriaUser={
          isBlocked:false,
          userType:AppConstraints.USER
      }
      let criteriaDriver={
            isBlocked:false,
            userType:AppConstraints.DRIVER
      }
      let criteriaService={
            isDeleted:false
      }
      let criteriaLaundry={
            isDeleted:false
      }
      let completedCriteria={
          status:AppConstraints.APP_CONST_VALUE.COMPLETED
      }



     let totalRevenue=await Bookings.find({status:AppConstraints.APP_CONST_VALUE.COMPLETED},{totalAmount:1,_id:0});
       


     console.log(totalRevenue,'=================')

      let totalAmmountToSend=0.0;
      for(let i=0;i<totalRevenue.length;i++){
          console.log(totalRevenue[i].totalAmount,'=======================amiount')
        totalAmmountToSend+=parseFloat(totalRevenue[i].totalAmount);
        console.log(totalAmmountToSend,'=================================')
      }


      let findData=await Promise.all([
          Admin.findOne({email:request.body.email,password:md5(request.body.password)}).select({password:0}),
          User.count(criteriaUser),
          Driver.count(criteriaDriver),
          Service.count(criteriaService),
          Laundry.count(criteriaLaundry),
          Bookings.count(),
          Bookings.count(completedCriteria)
      ])



    


      return response.status(200).json({
                                        statusCode:200,
                                        success:1,
                                        msg:'success',
                                        data:{
                                                adminData:findData[0],
                                                totalUser:findData[1],
                                                totalDriver:findData[2],
                                                totalService:findData[3],
                                                totalLaundry:findData[4],
                                                totalOrderRequest:findData[5],
                                                totalOrderComplete:findData[6],
                                                totalRevenue:totalAmmountToSend
                                            }
                                        });
      
  }catch(err){
      return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
  }
}




exports.createService=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});


        request.checkBody('serviceName',AppConstraints.SERVICE_NAME).notEmpty();
        request.checkBody('hexString',AppConstraints.HEX_STRING).notEmpty();
        request.checkBody('servicePicOriginal',AppConstraints.SERVICE_PIC_ORIGINAL).notEmpty();
        request.checkBody('servicePicThumbnail',AppConstraints.SERVICE_PIC_THUMBNAIL).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});

        let isService=await Service.findOne({serviceName:request.body.serviceName});
        if(isService)
        return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.ALREADY_SERVICE});
        
        let service=new Service();
        service.serviceName=request.body.serviceName;
        service.servicePic.servicePicOriginal=request.body.servicePicOriginal;
        service.servicePic.servicePicThumbnail=request.body.servicePicThumbnail;
        service.hexString=request.body.hexString;
        let createService=await service.save();

        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SERVICE_SUCCESSFULLY_CREATED,data:createService});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}



exports.createDriver=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});


        request.checkBody('callingCode',AppConstraints.CALLING_CODE).notEmpty();
        request.checkBody('email',AppConstraints.EMAIL_ADDRESS).notEmpty();
        request.checkBody('email',AppConstraints.VALID_EMAIL_ADDRESS).isEmail();
        request.checkBody('phoneNumber',AppConstraints.PHONE_NUMBER).notEmpty();
        request.checkBody('name',AppConstraints.NAME).notEmpty();
        request.checkBody('laundryId',AppConstraints.LAUNDRY_ID).notEmpty();
        request.checkBody('cityName',AppConstraints.CITY_NAME).notEmpty();
        request.checkBody('licencePicOriginal',AppConstraints.LICENCE_PIC_ORIGINAL).notEmpty();
        request.checkBody('licencePicThumbnail',AppConstraints.LICENCE_PIC_THUMBNAIL).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});


   
        if(!(!isNaN(parseFloat(request.body.phoneNumber)) && isFinite(request.body.phoneNumber)))
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.PHONE_NUMERIC});

        let criteriaEmail={
            email:request.body.email,
            userType:AppConstraints.DRIVER
        }


        let criteriaPhone={
            phoneNumber:request.body.phoneNumber,
            userType:AppConstraints.DRIVER
        }

        let ifEmailAlready=await Driver.findOne(criteriaEmail);
        if(ifEmailAlready)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.EMAIL_ALREADY});

        let ifPhoneAlready=await Driver.findOne(criteriaPhone);
        if(ifPhoneAlready)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.PHONE_ALREADY});


        let randomValue=  Math.floor(Date.now() / 1000) + (60 * 60);
        let rand = Math.floor((Math.random() * 1000) + 540000);
        let randomPassword=await randomstring.generate(8);



        console.log(randomPassword,'password of driver');



        let token=await UnivershalFunction.GenerateToken({email:request.body.email,userType:AppConstraints.DRIVER});

        let link=`${process.env.BASE_URL}verifyEmailDriverPage?id=${rand}&accessToken=${token}`;

        let content="<br />"+AppConstraints.CLICK_BELOW+"<br /><a href="+link+">"+AppConstraints.CLICK_HERE+"</a>";


        let link1=`${process.env.BASE_URL}renderResetDriver?id=${rand}&accessToken=${token}`;

        let content1="<br /><p>"+AppConstraints.YOUR_CREDENTIALS1+
                     "<br /><br /><br />"+AppConstraints.YOUR_CREDENTIALS2+
                     "</p><br /><dl><dt>Email address</dt><dd>- " +request.body.email+
                     "</dd><dt>Password</dt><dd>- " +randomPassword+"</dd></dl>"+
                     "<br />"+AppConstraints.CHANGE_ALSO+"<br /><br /><br />"+
                     "<a href="+link1+">"+AppConstraints.CLICK_HERE_TO_RESET+"</a>";




        let driver=new Driver();
        driver.name=request.body.name;
        driver.phoneNumber=request.body.phoneNumber;
        driver.email=request.body.email;
        driver.password=await md5(randomPassword);
        driver.licencePic.licencePicOriginal=request.body.licencePicOriginal;
        driver.licencePic.licencePicThumbnail=request.body.licencePicThumbnail;
        driver.emailVerificationcode=rand;
        driver.callingCode=request.body.callingCode;
        driver.userType=AppConstraints.DRIVER
        driver.cityName=request.body.cityName
        driver.laundryId=request.body.laundryId;

        console.log(driver,'driver data');




        let forgot = new Forgot();
        forgot.email=request.body.email;
        forgot.forgotCode=rand;
        forgot.userType=AppConstraints.DRIVER

        let createDriver=await Promise.all([
                forgot.save(),
                driver.save(),
                UnivershalFunction.sendEmail(request.body.email,content,AppConstraints.REGISTRATIONS_MESSAGE),
                UnivershalFunction.sendEmail(request.body.email,content1,AppConstraints.LOGIN_CREDENTIALS)
        ]);


       

        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.DRIVER_SUCCESSFULLY_CREATED,data:createDriver[1]});



    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.createLaundry=async(request,response)=>{
    try{


        console.log(request.body,'================request data===================');

        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});


        request.checkBody('laundryName',AppConstraints.LAUNDRY_NAME).notEmpty();
        request.checkBody('laundryAddress',AppConstraints.LAUNDRY_ADDRESS).notEmpty();
        request.checkBody('laundryLat',AppConstraints.LAUNDRY_LAT).notEmpty();
        request.checkBody('laundryLong',AppConstraints.LAUNDRY_LONG).notEmpty();
        request.checkBody('cityName',AppConstraints.CITY_NAME).notEmpty();
        request.checkBody('serviceId',AppConstraints.SERVICES_ID_REQUIRED).notEmpty();

        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});

        let criteria={
            laundryName:request.body.laundryName,
            laundryAddress:request.body.laundryAddress,
            laundryLat:request.body.laundryLat,
            laundryLong:request.body.laundryLong
        }

        let checkIfLaundryAlreadyCreated=await Laundry.findOne(criteria);

        if(checkIfLaundryAlreadyCreated)
        return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.LAUNDRY_ALREADY_CREATED});
       
        let latitude = parseFloat(request.body.laundryLat);
        let  longitude= parseFloat(request.body.laundryLong);
        let laundry=new Laundry();
        laundry.laundryName=request.body.laundryName;
        laundry.laundryAddress=request.body.laundryAddress;
        laundry.laundryLat=latitude;
        laundry.laundryLong=longitude;
        laundry.cityName=request.body.cityName;
        laundry.currentLocation=[longitude, latitude];
        let createLaundry=await laundry.save();

        if(request.body.serviceId){
           let serviceIds= JSON.parse(request.body.serviceId);
           for(let i=0;i<serviceIds.length;i++){
               await Laundry.update({_id:createLaundry._id},{$addToSet:{services:serviceIds[i]}});
           }
        }

        let findLaundryDetails=await Laundry.findOne({_id:createLaundry._id});
       

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.LAUNDRY_CREATED_SUCCESSFULLY,data:findLaundryDetails});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}



exports.blockUnblockUser=async(request,response)=>{
    try{


        console.log(request.body,'block unblock request data');



        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('userId',AppConstraints.USER_ID).notEmpty();
        request.checkBody('isBlocked',AppConstraints.BLOCKED_STATUS).notEmpty().isBoolean();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});

        await User.update({_id:request.body.userId},{$set:{isBlocked:request.body.isBlocked}});

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.SUCCESSFULLY_CHANGED_STATUS_OF_USER});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.getUserListing=async(request,response)=>{
    try{


        console.log(request.body,'request data for listing');

        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('page',AppConstraints.PAGE_NUMBER).notEmpty();
        request.checkBody('perPage',AppConstraints.PER_PAGE).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});


    
        let criteria={};

        if(request.body.fromDate && request.body.toDate && request.body.serachField){
            criteria={
            createDate:{$gte :new Date(request.body.fromDate),$lte :new Date(request.body.toDate)},
            name:new RegExp(request.body.serachField,'i'),
            userType:AppConstraints.USER
           }
        }


        else if(request.body.fromDate && request.body.toDate){
            criteria={
              
                createDate:{$gte :new Date(request.body.fromDate),$lte :new Date(request.body.toDate)},
                userType:AppConstraints.USER
               }  
        }


        else if(request.body.fromDate && request.body.serachField){
            criteria={
              
                createDate:{$gte :new Date(request.body.fromDate)},
                name:new RegExp(request.body.serachField,'i'),
                userType:AppConstraints.USER
                
               }  
        }

        else if(request.body.toDate && request.body.serachField){
            criteria={
               
                createDate:{$lte :new Date(request.body.toDate)},
                name:new RegExp(request.body.serachField,'i'),
                userType:AppConstraints.USER
               }  
        }
           

        else if(request.body.toDate){
            criteria={
              
                createDate:{$lte :new Date(request.body.toDate)},
                userType:AppConstraints.USER
               }  
        }

        else if(request.body.fromDate){
            criteria={
              
                createDate:{$gte :new Date(request.body.fromDate)},
                userType:AppConstraints.USER
               }  
        }

        else if(request.body.serachField){
            criteria={
             
                name:new RegExp(request.body.serachField,'i'),
                userType:AppConstraints.USER
               }  
        }

        else if(request.body.status==="BLOCKED"){
            criteria={
                isBlocked:true,
                userType:AppConstraints.USER
            }
        }

        else if(request.body.status==="UNBLOCKED"){
            criteria={
                userType:AppConstraints.USER,
                isBlocked:false
            }  
        }

        else{
            criteria={
                userType:AppConstraints.USER
            }  
        }


        let getData=await Promise.all([
            User.count(criteria),
            User.find(criteria)
            .sort({"_id":-1})
            .select({password:0,accessToken:0})
            .skip((parseInt(request.body.perPage) * parseInt(request.body.page)) - parseInt(request.body.perPage))
            .limit(parseInt(request.body.perPage))
        ])





      
        

        return response.status(200).json({success:1,msg:AppConstraints.SUCCESS,data:getData[1],totalResult:getData[0]});


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.getDriverListing=async(request,response)=>{
    try{

        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});



        request.checkBody('page',AppConstraints.PAGE_NUMBER).notEmpty();
        request.checkBody('perPage',AppConstraints.PER_PAGE).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});


        let criteria={}

        if(request.body.fromDate && request.body.toDate && request.body.serachField){
            criteria={
            createDate:{$gte:new Date(request.body.fromDate),$lte :new Date(request.body.toDate)},
            name:new RegExp(request.body.serachField,'i'),
            userType:AppConstraints.DRIVER
           }
        }


        else if(request.body.fromDate && request.body.toDate){
            criteria={
                createDate:{$gte :new Date(request.body.fromDate),$lte :new Date(request.body.toDate)},
                userType:AppConstraints.DRIVER
               }  
        }


        else if(request.body.fromDate && request.body.serachField){
            criteria={
                createDate:{$gte :new Date(request.body.fromDate)},
                name:new RegExp(request.body.serachField,'i'),
                userType:AppConstraints.DRIVER
               }  
        }

        else if(request.body.toDate && request.body.serachField){
            criteria={
                createDate:{$lte :new Date(request.body.toDate)},
                name:new RegExp(request.body.serachField,'i'),
                userType:AppConstraints.DRIVER
               }  
        }
           

        else if(request.body.toDate){
            criteria={
                createDate:{$lte :new Date(request.body.toDate)},
                userType:AppConstraints.DRIVER
               }  
        }

        else if(request.body.fromDate){
            criteria={
                createDate:{$gte :new Date(request.body.fromDate)},
                userType:AppConstraints.DRIVER
               }  
        }

        else if(request.body.serachField){
            criteria={
                name:new RegExp(request.body.serachField,'i'),
                userType:AppConstraints.DRIVER
               }  
        }


        else if(request.body.status==="BLOCKED"){
            criteria={
                isBlocked:true,
                userType:AppConstraints.DRIVER
            }
        }

        else if(request.body.status==="UNBLOCKED"){
            criteria={
                userType:AppConstraints.DRIVER,
                isBlocked:false
            }  
        }


        else{
            criteria={
                userType:AppConstraints.DRIVER
               }  
        }


        let getData=await Promise.all([
            Driver.count(criteria),
            Driver.find(criteria)
            .sort({"_id":-1})
            .populate({path:'laundryId',select:{laundryName:1}})
            .select({password:0,accessToken:0})
            .skip((parseInt(request.body.perPage)*parseInt(request.body.page)) - parseInt(request.body.perPage))
            .limit(parseInt(request.body.perPage))
        ])

       

        return response.status(200).json({success:1,msg:AppConstraints.SUCCESS,data:getData[1],totalResult:getData[0]});


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}








exports.getServiceListing=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});



        // request.checkBody('page',AppConstraints.PAGE_NUMBER).notEmpty();
        // request.checkBody('perPage',AppConstraints.PER_PAGE).notEmpty();
        // let errors = await request.validationErrors();
        // if (errors)
        // return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});


        let criteria={}

        if(request.body.fromDate && request.body.toDate && request.body.serachField){
            criteria={
            isDeleted:false,
            createDate:{$gte :new Date(request.body.fromDate),$lte :new Date(request.body.toDate)},
            serviceName:new RegExp(request.body.serachField,'i')
           }
        }


        else if(request.body.fromDate && request.body.toDate){
            criteria={
                isDeleted:false,
                createDate:{$gte :new Date(request.body.fromDate),$lte :new Date(request.body.toDate)},
               }  
        }


        else if(request.body.fromDate && request.body.serachField){
            criteria={
                isDeleted:false,
                createDate:{$gte :new Date(request.body.fromDate)},
                serviceName:new RegExp(request.body.serachField,'i')
               }  
        }

        else if(request.body.toDate && request.body.serachField){
            criteria={
                isDeleted:false,
                createDate:{$lte :new Date(request.body.toDate)},
                serviceName:new RegExp(request.body.serachField,'i')
               }  
        }
           

        else if(request.body.toDate){
            criteria={
                isDeleted:false,
                createDate:{$lte :new Date(request.body.toDate)}
               }  
        }


        else if(request.body.fromDate){
            criteria={
                isDeleted:true,
                createDate:{$gte :new Date(request.body.fromDate)}
               }  
        }

        else if(request.body.status=='BLOCKED'){
            criteria={
                isDeleted:true,
            }  
        }

        else if(request.body.status=='ACTIVE'){
            criteria={
                isDeleted:false,
            }  
        }

        else if(request.body.serachField){
            criteria={
                isDeleted:false,
                serviceName:new RegExp(request.body.serachField,'i')
               }  
        }

        else{
            criteria={
               
               }  
        }


        let getData=await Promise.all([
            Service.count(criteria),
            Service.find(criteria)
            .sort({"_id":-1})
            // .skip((parseInt(request.body.perPage)*parseInt(request.body.page)) - parseInt(request.body.perPage))
            // .limit(parseInt(request.body.perPage))
        ])

       

        return response.status(200).json({success:1,msg:AppConstraints.SUCCESS,data:getData[1],totalResult:getData[0]});
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}



exports.blockUnblockDriver=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('driverId',AppConstraints.DRIVER_ID).notEmpty();
        request.checkBody('isBlocked',AppConstraints.BLOCKED_STATUS).notEmpty().isBoolean();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});

        await Driver.update({_id:request.body.driverId},{$set:{isBlocked:request.body.isBlocked}});

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.SUCCESSFULLY_CHANGED_STATUS_OF_USER});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}

exports.getAllLaundryList=async(request,response)=>{
    try{


    console.log(request.query,'request data')


    if(!request.headers['authorization'])
    return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
    let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
    if(!validateToken)
    return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});



    // request.checkBody('page',AppConstraints.PAGE_NUMBER).notEmpty();
    // request.checkBody('perPage',AppConstraints.PER_PAGE).notEmpty();
    let errors = await request.validationErrors();
    if (errors)
    return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});


    let criteria;

    

    if(request.body.fromDate && request.body.toDate && request.body.serachField){
        criteria={
        isDeleted: false,
        createDate:{$gte :new Date(request.body.fromDate),$lte :new Date(request.body.toDate)},
        laundryName:new RegExp(request.body.serachField,'i')
       }
    }


    else if(request.body.fromDate && request.body.toDate){
        criteria={
            isDeleted: false,
            createDate:{$gte :new Date(request.body.fromDate),$lte :new Date(request.body.toDate)},
           }  
    }


    else if(request.body.fromDate && request.body.serachField){
        criteria={
            isDeleted: false,
            createDate:{$gte :new Date(request.body.fromDate)},
            laundryName:new RegExp(request.body.serachField,'i')
           }  
    }

    else if(request.body.toDate && request.body.serachField){
        criteria={
            isDeleted: false,
            createDate:{$lte :new Date(request.body.toDate)},
            laundryName:new RegExp(request.body.serachField,'i')
           }  
    }
       

    else if(request.body.toDate){
        criteria={
            isDeleted: false,
            createDate:{$lte :new Date(request.body.toDate)}
           }  
    }

    else if(request.body.fromDate){
        criteria={
            isDeleted: false,
            createDate:{$gte :new Date(request.body.fromDate)}
           }  
    }

    else if(request.body.serachField){
        criteria={
            isDeleted: false,
            laundryName:new RegExp(request.body.serachField,'i')
           }  
    }


    else if(request.body.status=="BLOCKED"){
        criteria={
            isDeleted: true
        }
    }


    else if(request.body.status=="ACTIVE"){
        criteria={
            isDeleted: false
        }
    }

    else{
        criteria={isDeleted: false}  
    }

    let getData

    if(request.body.page&&request.body.perPage){
        getData=await Promise.all([
            Laundry.count(criteria),
            Laundry.find(criteria)
            .sort({"_id":-1})
            .skip((parseInt(request.body.perPage)*parseInt(request.body.page))-parseInt(request.body.perPage))
            .limit(parseInt(request.body.perPage))
            
        ]);
    }else{
         getData=await Promise.all([
            Laundry.count(criteria),
            Laundry.find(criteria)
            .sort({"_id":-1})
    
        ]);
    }

    

   

    return response.status(200).json({success:1,msg:AppConstraints.SUCCESS,data:getData[1],totalResult:getData[0]});
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}

exports.editOrDeleteService=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('status',AppConstraints.STATUS).notEmpty();
        request.checkBody('serviceId',AppConstraints.SERVICE_ID).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});

        if(request.body.status==="DELETE"){
            let deleteService=await Service.update({_id:request.body.serviceId},{$set:{isDeleted:true}});
            return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.SERVICE_DELETED});
        }
        else if(request.body.status==="EDIT"){
            
            let dataToSet={};
            if(request.body.serviceName){
                let isService=await Service.findOne({serviceName:request.body.serviceName});
                if(isService && (""+isService._id===request.body.serviceId)){
                    dataToSet['serviceName']=request.body.serviceName;
                }
                else if(isService && (""+isService._id!==request.body.serviceId)){
                    return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.ALREADY_SERVICE});
                }
                else{
                    dataToSet['serviceName']=request.body.serviceName;
                }
                
            }

            if(request.body.servicePicOriginal){
                dataToSet['servicePic.servicePicOriginal']=request.body.servicePicOriginal;
            }


            if(request.body.servicePicThumbnail){
                dataToSet['servicePic.servicePicThumbnail']=request.body.servicePicThumbnail;
            }

            if(request.body.hexString){
                dataToSet['hexString']=request.body.hexString;
            }


            let dataToUpdate={
                $set:dataToSet
            }
            
            let criteria={
                _id:request.body.serviceId
            }

            let editService=await Service.update(criteria,dataToUpdate);


            return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.SERVICE_EDIT});
        }

        else {
            return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.SEND_CORRECT});
        }

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}



exports.editDriver=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
     
        request.checkBody('driverId',AppConstraints.DRIVER_ID).notEmpty();
        request.checkBody('driverId',AppConstraints.DRIVER_ID_VALID).isMongoId();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});


        let checkIfDriverExist=await Driver.findOne({_id:request.body.driverId,userType:AppConstraints.DRIVER});
        if(!checkIfDriverExist)
        return response.status(400).json({success:1,statusCode:400,msg:AppConstraints.INVALID_DRIVER_ID});
        


        let dataToSet={};
        if(request.body.name){
            dataToSet['name']=request.body.name;
        }
        if(request.body.email){

            let findDriver=await Driver.findOne({email:request.body.email,userType:AppConstraints.DRIVER});

            if(!findDriver){
                dataToSet['email']=request.body.email;
            }

            else if(findDriver && (request.body.driverId!== ""+findDriver._id)){
                return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.EMAIL_ALREADY});
            }

            else if(findDriver && (request.body.driverId===""+findDriver._id)){
                dataToSet['email']=request.body.email;
            }
        }


     

        if(request.body.phoneNumber){
            let findDriver=await User.findOne({phoneNumber:request.body.phoneNumber,userType:AppConstraints.DRIVER});

            if(!findDriver){
                dataToSet['phoneNumber']=request.body.phoneNumber;
            }

            else if(findDriver && (request.body.driverId!== ""+findDriver._id)){
                return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.EMAIL_ALREADY});
            }

            else if(findDriver && (request.body.driverId===findDriver._id)){
                dataToSet['phoneNumber']=request.body.phoneNumber;
            }
        }


        if(request.body.licencePicOriginal){
            dataToSet['licencePic.licencePicOriginal']=request.body.licencePicOriginal;
        }

        if(request.body.licencePicThumbnail){
             dataToSet['licencePic.licencePicThumbnail']=request.body.licencePicThumbnail;
        }

        if(request.body.cityName){
            dataToSet['cityName']=request.body.cityName;
       }



        await Driver.update({_id:request.body.driverId},{$set:dataToSet});

        let getDriverData=await Driver.findOne({_id:request.body.driverId});

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.SUCCESS,data:getDriverData});


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}



exports.editOrDeleteLaundry=async(request,response)=>{
    try{


        console.log(request.body,'===================================request data=================================')

        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
     
        request.checkBody('laundryId',AppConstraints.LAUNDRY_ID).notEmpty();
        request.checkBody('laundryId',AppConstraints.LAUNDRY_ID_NOT_VALID).isMongoId();
        request.checkBody('status',AppConstraints.STATUS).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});

        if(request.body.status==="DELETE"){
            
           let updateLaundrydata= await Laundry.update({_id:request.body.laundryId},{$set:{isDeleted:true}});
           console.log(updateLaundrydata,'updateLaundrydata') 
           return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.LAUNDRY_DELETED});
        }
        else if(request.body.status==="EDIT"){


            let isLaundry=await Laundry.findOne({_id:request.body.laundryId});

            if(!isLaundry)
            return response.status(200).json({success:0,msg:AppConstraints.INVALID_LAUNDRY_ID})

            let dataToSet={};
            if(request.body.laundryName){
                dataToSet['laundryName']=request.body.laundryName;
            }
            if(request.body.laundryLat){
                dataToSet['laundryLat']=request.body.laundryLat;
            }

            if(request.body.laundryLong){
                dataToSet['laundryLong']=request.body.laundryLong
            }

            if(request.body.laundryAddress){
                dataToSet['laundryAddress']=request.body.laundryAddress;
            }


            if(request.body.cityName){
                dataToSet['cityName']=request.body.cityName;
            }


            // if(request.body.laundryAddress){
            //     dataToSet['services']=;
            // }

            if(request.body.laundryLat && request.body.laundryLong){
                dataToSet['currentLocation']=[parseFloat(request.body.laundryLong),parseFloat(request.body.laundryLat)]
            }

            
            await Laundry.update({_id:request.body.laundryId},{$set:dataToSet});



            if(request.body.serviceId){
                let serviceIds= JSON.parse(request.body.serviceId);
                for(let i=0;i<serviceIds.length;i++){
                    await Laundry.update({_id:request.body.laundryId},{$addToSet:{services:serviceIds[i]}});
                }
             }
     
            let findLaundryData=await Laundry.findOne({_id:request.body.laundryId});

            return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.LAUNDRY_UPDATED_SUCCESSFULLY,data:findLaundryData});


        }

        else{
            return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.INVALID_STATUS});
        }

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.createServiceItems=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('serviceId',AppConstraints.SERVICE_ID).notEmpty();
        request.checkBody('serviceId',AppConstraints.SERVICE_ID_NOT_VALID).isMongoId();
        request.checkBody('itemName',AppConstraints.SERVICE_ITEM_NAME).notEmpty();
        request.checkBody('itemNameAr',AppConstraints.SERVICE_ITEM_NAME).notEmpty();
        request.checkBody('itemPicOriginal',AppConstraints.SERVICE_ITEM_PIC_ORIGINAL).notEmpty();
        request.checkBody('itemPicThumbnail',AppConstraints.SERVICE_ITEM_PIC_THUMBNAIL).notEmpty();
        request.checkBody('amountPerItem',AppConstraints.AMMOUNT_PER_ITEM).notEmpty()
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});

        let criteria={
            serviceId:request.body.serviceId,
            itemName:request.body.itemName
        }

        let checkIfAlreadyCreated=await serviceItem.findOne(criteria);
        if(checkIfAlreadyCreated)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ALREADY_CREATED_ITEM})

        let serviceitem=new serviceItem();
        serviceitem.serviceId=request.body.serviceId;
        serviceitem.itemName=request.body.itemName;
        serviceitem.itemNameAr=request.body.itemNameAr;
        serviceitem.itemPic.itemPicOriginal=request.body.itemPicOriginal;
        serviceitem.itemPic.itemPicThumbnail=request.body.itemPicThumbnail;
        serviceitem.amountPerItem=request.body.amountPerItem;

        let createItem=await serviceitem.save();

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.ITEM_CREATED,data:createItem});


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error}); 
    }
}



exports.editOrDeleteServiceItems=async(request,response)=>{
    try{

        console.log(request.body,'request data')
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('serviceItemId',AppConstraints.SERVICE_ITEM_ID).notEmpty();
        request.checkBody('serviceId',AppConstraints.SERVICE_ID).notEmpty();
        request.checkBody('status',AppConstraints.STATUS).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});

        if(request.body.status==='DELETE'){
            let criteria={
                _id:request.body.serviceItemId,
                serviceId:request.body.serviceId
            }

            await serviceItem.update(criteria,{$set:{isDeleted:true}});
            return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.ITEM_DELETED_SUCCESSFULLY});
        }
        else if(request.body.status==='EDIT'){

            let dataToSet={};
            if(request.body.itemName){
    
    
                let criteria={
                    itemName:request.body.itemName,
                    serviceId:request.body.serviceId
                }
    
                let findItemAlready=await serviceItem.findOne(criteria);
                if(!findItemAlready){
                    dataToSet['itemName']=request.body.itemName;
                }
    
                else if(findItemAlready && (""+findItemAlready._id!==request.body.serviceItemId)){
                    return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.ALREADY_CREATED_ITEM});
                }
    
                else{
                    dataToSet['itemName']=request.body.itemName;
                }
    
                
                
               
            }
    
    
    
            if(request.body.itemPicOriginal){
                dataToSet['itemPic.itemPicOriginal']=request.body.itemPicOriginal;
            }
    
    
            if(request.body.itemPicOriginal){
                dataToSet['itemPic.itemPicThumbnail']=request.body.itemPicThumbnail;
            }
    
    
            if(request.body.amountPerItem){
                dataToSet['amountPerItem']=request.body.amountPerItem;
            }
    
    
            let criteria={
                _id:request.body.serviceItemId,
                serviceId:request.body.serviceId
            }
    
        

            await serviceItem.update(criteria,{$set:dataToSet});

            let findUpdatedData=await serviceItem.findOne(criteria);
    
            return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.ITEM_UPDATED_SUCCESSFULLY,data:findUpdatedData});

        }

        else{
            return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.INVALID_STATUS});
        }

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error}); 
    }
}


exports.createSubscriptionPlan=async(request,response)=>{
    try{
        console.log(request.body,'request data')
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('planName',AppConstraints.PLANE_NAME).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});


        let findIfAlreadySubs=await SubscriptionPlane.findOne({planName:request.body.planName});
        if(findIfAlreadySubs)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ALREADY_SUBSCRIPTION_PLAN})


        console.log('request plane',request.body.planName)

        let subscriptionplane=new SubscriptionPlane();
        subscriptionplane.planName=request.body.planName;
        subscriptionplane.planAmount=request.body.planAmount||"";
        subscriptionplane.perPeriod=request.body.perPeriod||"";

        let saveSubscription=await subscriptionplane.save();

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.SUBSCRIPTION_PLANE_CREATED,data:saveSubscription});


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error}); 
    }
}


exports.editOrDeleteSubscriptionPlane=async(request,response)=>{
    try{
        console.log(request.body,'request data')
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('planId',AppConstraints.PLANE_ID).notEmpty();
        request.checkBody('planId',AppConstraints.PLANE_ID_NOT_VALID).isMongoId();
        request.checkBody('status',AppConstraints.STATUS).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});


        if(request.body.status==="DELETE"){



            let deletePlane=await SubscriptionPlane.update({_id:request.body.planId},{$set:{isDeleted:true}});
            return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.PLANE_DELETED});
        }

        else if(request.body.status==="EDIT"){

            let dataToSet={};

            if(request.body.planName){

                let findIfAlreadPlane=await SubscriptionPlane.findOne({planName:request.body.planName});

                if(findIfAlreadPlane){
                    if(""+findIfAlreadPlane._id===request.body.planId){
                        dataToSet['planName']=request.body.planName;
                    }
                    else{
                        return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.ALREADY_SUBSCRIPTION_PLAN})
                    }
                }
                else{
                    dataToSet['planName']=request.body.planName;
                }

               
            }

            
                dataToSet['planAmount']=request.body.planAmount;
                dataToSet['perPeriod']=request.body.perPeriod;


                await SubscriptionPlane.update({_id:request.body.planId},{$set:dataToSet});
                let getPlaneData=await SubscriptionPlane.findOne({_id:request.body.planId})

                return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.PLANE_UPDATED,data:getPlaneData});

         

        }
        else{
            return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.INVALID_STATUS});
        }

        

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}



exports.createSubscriptionPlaneItem=async(request,response)=>{
    try{
        console.log(request.body,'request data')
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('planId',AppConstraints.PLANE_ID).notEmpty();
        request.checkBody('planId',AppConstraints.PLANE_ID_NOT_VALID).isMongoId();
        request.checkBody('itemQwery',AppConstraints.ITEM_QWERY).notEmpty();
        request.checkBody('itemStatus',AppConstraints.ITEM_STATUS).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});

        let ifAlreadyItem=await SubscriptionPlaneItem.findOne({planId:request.body.planId,itemQwery:request.body.itemQwery});

        if(ifAlreadyItem)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ALREADY_PLAN_ITEM});


        

        let planItem=new SubscriptionPlaneItem();
        planItem.planId=request.body.planId;
        planItem.itemQwery=request.body.itemQwery;
        planItem.itemStatus=request.body.itemStatus;


        console.log(planItem,'plan item data');

        let createPlaneItem=await planItem.save();


        // console


        return response.status(200).json({statusCode:400,success:1,msg:AppConstraints.PLANE_ITEM_CREATED,data:createPlaneItem})



    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.editOrDeleteSubscriptionPlaneItem=async(request,response)=>{
    try{
        console.log(request.body,'request data')
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});


        request.checkBody('planItemId',AppConstraints.PLANE_ITEM_ID).notEmpty();
        request.checkBody('status',AppConstraints.PLANE_ID_STATUD).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});


        if(request.body.status==="DELETE"){
          
            await SubscriptionPlaneItem.update({_id:request.body.planItemId},{$set:{isDeleted:true}})
            return response.status(200).json({success:1,msg:AppConstraints.PLANE_ITEM_DELETED,statusCode:200})
        }
        else if(request.body.status==="EDIT"){

            let dataToSet={};

            if(request.body.itemQwery){


                let findQweryItem=await SubscriptionPlaneItem.findOne({itemQwery:request.body.itemQwery});
                if(findQweryItem){
                    if(""+findQweryItem._id===request.body.planItemId){
                        dataToSet['itemQwery']=request.body.itemQwery;
                    }
                    else{
                        return response.status(200).json({success:1,msg:AppConstraints.ITEM_QWERY_ALREADY,statusCode:400});
                    }
                }
                else{
                    dataToSet['itemQwery']=request.body.itemQwery;
                }

               
            }

            if(request.body.itemStatus){
                dataToSet['itemStatus']=request.body.itemStatus;
            }


            await SubscriptionPlaneItem.update({_id:request.body.planItemId},{$set:dataToSet});

           let data=await SubscriptionPlaneItem.findOne({_id:request.body.planItemId});
            return response.status(200).json({statusCode:200,success:1,data:data,msg:AppConstraints.SUCCESSFULLY_UPDATED_ITEM})

        }
        else{
            return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.INVALID_STATUS});
        }

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}



exports.assignBookingToDriver=async(request,response)=>{
    try{
        console.log(request.body,'request data')
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});


       
        request.checkBody('driverId',AppConstraints.DRIVER_ID).notEmpty();
        request.checkBody('driverId',AppConstraints.DRIVER_ID_VALID).isMongoId();
        request.checkBody('bookingId',AppConstraints.BOOKING_ID).notEmpty();
        request.checkBody('bookingId',AppConstraints.BOOKING_ID_VALID).isMongoId();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});
        let findBookingData=await Bookings.findOne({_id:request.body.bookingId}).populate({path:'userId',select:{}});
        let findDeviceToken=await User.findOne({_id:request.body.driverId});
        if(!findDeviceToken.isAvailable)
        return response.status(200).json({success:0,statusCode:400,msg:AppConstraints.DRIVER_NOT_AVAILABLE})
       
        let criteria={
            recieverId:request.body.driverId,
            isRead:false
        }
        let findTotalUnreadCount=await NotificationData.count(criteria);

        let d=new Date();

        let dataToPush={
            msg:AppConstraints.BOOKING_ASSIGNED,
            messageType:AppConstraints.APP_CONST_VALUE.ASSIGNED_ORDER,
            userId:findBookingData.userId._id,
            bookingId:request.body.bookingId,
            count:findTotalUnreadCount+1
        }


        let newNotification=new NotificationData();
        newNotification.recieverId=request.body.driverId,
        newNotification.bookingId=request.body.bookingId;
        newNotification.msg=AppConstraints.BOOKING_ASSIGNED;
        newNotification.messageType=AppConstraints.APP_CONST_VALUE.ASSIGNED_ORDER;







        let criteriaUser={
            recieverId:request.body.driverId,
            isRead:false
        }

        let findTotalUnreadCountUser=await NotificationData.count(criteriaUser);

      

        let dataToPushUser={
            msg:AppConstraints.BOOKING_ASSIGNED_USER_NOTIFICATION,
            messageType:AppConstraints.APP_CONST_VALUE.ASSIGNED_ORDER,
            userId:findBookingData.userId._id,
            bookingId:request.body.bookingId,
            count:findTotalUnreadCountUser+1
        }


        let newNotificationUser=new NotificationData();
        newNotificationUser.recieverId=findBookingData.userId._id,
        newNotificationUser.bookingId=request.body.bookingId;
        newNotificationUser.msg=AppConstraints.BOOKING_ASSIGNED_USER_NOTIFICATION;
        newNotificationUser.messageType=AppConstraints.APP_CONST_VALUE.ASSIGNED_ORDER;

        await Promise.all([
            Bookings.update({_id:request.body.bookingId},
                            {$set:{driverId:request.body.driverId,
                                   status:AppConstraints.APP_CONST_VALUE.ASSIGNED_ORDER,
                                   assignedStatusCount:findBookingData.assignedStatusCount+1,
                                   assignedTime:new Date().getTime()}
                            }),
            pushNotification.sendPush(findDeviceToken.deviceToken,dataToPush),
            pushNotification.sendPushToUser(findBookingData.userId.deviceToken,dataToPushUser),
            newNotification.save(),
            newNotificationUser.save()
        ]);

        let findBooking=await Bookings.findOne({_id:request.body.bookingId});
        await SocketManager.emitAssignedBooking(findBooking);
        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESSFULLY_ASSIGNED})

    }catch(err){
        console.log(err,'error data++++++++++++')
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.subscriptionPlanListing=async(request,response)=>{
    try{
        console.log(request.body,'request data')
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

      
       

        let criteria={
            isDeleted:false
        }

        let findSubscriptionPlane=await SubscriptionPlane.aggregate([
                                                            {$match:criteria},      
                                                            { $lookup:
                                                                {
                                                    
                                                                from:'subscriptionplanitems',
                                                                localField: '_id',
                                                                foreignField: 'planId',
                                                                as: 'planDetails'
                                                                }
                                                            },

                                                            {
                                                            $project:{
                                                                "_id" : 1, 
                                                                "isDeleted" :1, 
                                                                "created_at" : 1, 
                                                                "isActive" : 1, 
                                                                "perPeriod" : 1, 
                                                                "planAmount" :1, 
                                                                "planName" : 1, 
                                                                "__v" : 1,
                                                                planDetails:{$filter: {
                                                                input: "$planDetails",
                                                                as: "item",
                                                                cond: { $eq: [ "$$item.isDeleted", false ] }
                                                                }}
                                                            }}
    ]);

        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESS,data:findSubscriptionPlane});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.createPrmoCode=async(request,response)=>{
    try{
        console.log(request.body,'request data for promocode');
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});


        request.checkBody('promoCode',AppConstraints.PROMO_CODE).notEmpty();
        request.checkBody('expiryDate',AppConstraints.EXPIRY_DATE).notEmpty();
        request.checkBody('discount',AppConstraints.DISCOUNT).notEmpty();
        request.checkBody('message',AppConstraints.MESSAGE).notEmpty();
        request.checkBody('startDate',AppConstraints.START_DATE).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});


        let ifAlreadyPromos=await PromoCode.findOne({promoCode:request.body.promoCode});


        if(ifAlreadyPromos)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ALREADY_PROMO});

        let d1 = new Date();
        let d2 = new Date(request.body.expiryDate)

        if(d2.getTime()>d1.getTime()){
            return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.EXPIRY_DATE_VALID})
        }

        let startDate=new Date(request.body.startDate)

        // if(startDate.getTime()<d1.getTime()){
        //     return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.START_DATE_LESSER})
        // }

        if(parseInt(request.body.discount)>100){
            return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.DISCOUNT_NOT_MORE_100})
        }

        let promocode=new PromoCode();


        promocode.promoCode=request.body.promoCode
        promocode.expiryDate=new Date(parseInt(request.body.expiryDate)).getTime();
        promocode.discount=request.body.discount;
        promocode.message=request.body.message;
        promocode.discount=parseFloat(request.body.discount);
        promocode.startDate=new Date(parseInt(request.body.startDate)).getTime();



        let promoCodeSaved=await promocode.save();
        let findUserTokens=await User.find({isBlocked:false,userType:AppConstraints.USER}).select({deviceToken:1});
        let allTokens=await findUserTokens.map((val)=>{
            let token=val.deviceToken;
            return token;
        });
        let dataToPush={};

        dataToPush.msg=request.body.message;
        dataToPush.promocode=request.body.promocode;
        dataToPush.messageType=AppConstraints.APP_CONST_VALUE.PROMO;
        dataToPush.msg=request.body.message;
        dataToPush.promocodeId=promoCodeSaved._id;

      
        
        await pushNotification.sendPushToAllUser(allTokens,dataToPush)
     

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.PROMO_CODE_SUCCESS});            


    }catch(err){
        console.log(err,'error in data')
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.getAllbookingList=async(request,response)=>{
    try{
        console.log(request.body,'request data');
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('perPage',AppConstraints.PER_PAGE).notEmpty();
        request.checkBody('page',AppConstraints.PAGE).notEmpty();
        request.checkBody('status',AppConstraints.STATUS_BOOKING).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg, error:errors});
        let criteria;
        if(request.body.status==='ALL'){
            criteria={}
        }else{
             criteria={
                status:request.body.status
            }
        }
      

        let getBooking=await Promise.all([
            Bookings.count(criteria),
            Bookings.find(criteria)
            .sort({"_id":-1})
            .skip((parseInt(request.body.perPage)*parseInt(request.body.page))-parseInt(request.body.perPage))
            .limit(parseInt(request.body.perPage))
            .populate({path:'laundryId',select:{}})
            .populate({path:'userId',select:{password:0,accessToken:0,licencePic:0}})
            .populate({path:'driverId',select:{password:0,accessToken:0,licencePic:0}})
        ]);


        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.SUCCESS,data:getBooking[1],totalResult:getBooking[0]});



    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.getListOfReviews=async(request,response)=>{
    try{
        console.log(request.body,'request data');
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        let criteria={
            isDeleted:false
        };


        if(request.query.searchText){
            criteria={
                isDeleted:false,
                description:new RegExp(request.query.searchText,'i')
            };
            
        }




        let findReview=await Review.find(criteria).populate({path:'userId',select:{password:0,accessToken:0}});

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.SUCCESS,data:findReview});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.addVehicle=async(request,response)=>{
    try{
        
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        request.checkBody('VehicleName',AppConstraints.VEHICLE_NAME).notEmpty();
        request.checkBody('VehicleNumber',AppConstraints.VEHICLE_NUMBER).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg, error:errors});
        let findAlreadyAddedVehicle=await Vehicle.findOne({VehicleNumber:request.body.VehicleNumber});
        if(findAlreadyAddedVehicle)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ALREADY_VEHICLE});
        let vehicle=new Vehicle();
        vehicle.VehicleName=request.body.VehicleName;
        vehicle.VehicleNumber=request.body.VehicleNumber;
        let saveVehicle=await vehicle.save();

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.VEHICLE_ADDED,data:saveVehicle});


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.editOrDeleteVehicle=async(request,response)=>{
    try{


        console.log('edit vehicle',request.body);



        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('status',AppConstraints.STATUS).notEmpty();
        request.checkBody('vehicleId',AppConstraints.VEHILCE_ID).notEmpty().isMongoId();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg, error:errors});

        if(request.body.status==='EDIT'){

           let dataToSave={}
         
           if(request.body.VehicleName!=null || request.body.VehicleName!=''){
            dataToSave['VehicleName']=request.body.VehicleName;
           }
           if(request.body.VehicleNumber!=null ||request.body.VehicleNumber!=''){
            dataToSave['VehicleNumber']=request.body.VehicleNumber;
           }

            await Vehicle.update({_id:request.body.vehicleId},{$set:dataToSave});

            let dataToSendToUser=await Vehicle.findOne({_id:request.body.vehicleId})

            return response.status(200).json({success:1,msg:AppConstraints.SUCCESS,data:dataToSendToUser})

        }
        else if(request.body.status==='DELETE'){
            await Vehicle.update({_id:request.body.vehicleId},{$set:{isDeleted:true}});
            return response.status(200).json({success:1,msg:AppConstraints.SUCCESS})
        }
       else{
            return response.status(200).json({success:1,msg:'Invalid status'})
       }

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.getVehicleListing=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        let criteria={};

        criteria={
            isDeleted:false
        }

        if(request.query.searchText){
            criteria={
                $and:[
                    {isDeleted:false},
                    {$or:[{VehicleName:new RegExp(request.query.searchText,'i')},{VehicleNumber:new RegExp(request.query.searchText,'i')}]}
                ]
            }
        }

        let findVehicle=await Vehicle.find(criteria);

        return response.status(200).json({success:1,msg:AppConstraints.SUCCESS,statusCode:200,data:findVehicle});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}

exports.getPerticularUserData=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkQuery('userId',AppConstraints.USER_ID).notEmpty().isMongoId();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg, error:errors});

        
        let findUserData=await User.findOne({_id:request.body.userId},{accessToken:0,password:0});

        console.log(findUserData)

        if(!findUserData)
        return response.status(400).json({statusCode:400,success:1,msg:AppConstraints.INVALID_USER_ID})

        return response.status(200).json({success:1,statusCode:400,msg:AppConstraints.SUCCESS,data:findUserData});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.quickReviewWash=async(request,response)=>{
    try{

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.giveIncentivesToDriver=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('driverId',AppConstraints.DRIVER_ID).notEmpty().isMongoId();
        request.checkBody('incentive',AppConstraints.INCENTIVE_REQUIRED).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg, error:errors});


        let findDriver=await User.findOne({_id:request.body.driverId});

        if(!findDriver)
        return response.status(400).json(AppConstraints.INVALID_DRIVER_ID2);

        await User.update({_id:request.body.driverId},{$set:{incentive:request.body.incentive}});

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.SUCCESS});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.createCharge=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('quickCharge',AppConstraints.QUICK_CHARGE).notEmpty();
        request.checkBody('deliveryCharge',AppConstraints.DELIVERY_CHARGE).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});

        let findIfAlreadCharge=await Charge.find();

        if(findIfAlreadCharge.length>0){
            await Charge.update({_id:findIfAlreadCharge[0]._id},{$set:{quickCharge:request.body.quickCharge,deliveryCharge:request.body.deliveryCharge}});
            let finCharge=await Charge.find();
            return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.CHARGE_UPDATED_SUCCESSFULLY,data:finCharge})
        }

        let charge=new Charge();
        charge.quickCharge=request.body.quickCharge;
        charge.deliveryCharge=request.body.deliveryCharge;
        let saveCharge=await charge.save();
        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.CHARGE_CREATED_SUCCESSFULLY,data:saveCharge})


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error}); 
    }
}


exports.promocodeListingToAdmin=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        let criteria={};

        if(request.query.status=='ACTIVE'){
            criteria.isDeleted=false
        }
        else if(request.query.status=='BLOCKED'){
            criteria.isDeleted=true
        }
        
        let findPromocode=await PromoCode.find(criteria);

        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESS,data:findPromocode})

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error}); 
    }
}

exports.updateSubscriptionPlanAndPlanItem=async(request,response)=>{
    try{
        console.log(request.body,'request data')
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        request.checkBody('planId',AppConstraints.PLANE_ID).notEmpty().isMongoId();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});


        if(request.body.planItem.length<=0){
            return response.status(400).json({success:0,msg:AppConstraints.ATLEAST_ONE_ITEM})
        }

        let findIfAlreadySubs=await SubscriptionPlane.findOne({planName:request.body.planName});
        if(findIfAlreadySubs)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ALREADY_SUBSCRIPTION_PLAN})


        let dataToSet={};

        if(request.body.planName){
            dataToSet['planName']=request.body.planName;
        }
       
        dataToSet['planAmount']=request.body.planAmount;
    
    
        dataToSet['perPeriod']=request.body.perPeriod;
       

        await SubscriptionPlane.update({_id:request.body.planId},{$set:dataToSet});
       
        if(request.body.planItem && request.body.planItem.length>0){


            for(let i=0;i<request.body.planItem.length;i++){

             

                let dataToSave={}
                if(request.body.planItem[i].itemQwery){
                    dataToSave['itemQwery']=request.body.planItem[i].itemQwery
                }
                if(request.body.planItem[i].itemStatus){
                    dataToSave['itemStatus']=request.body.planItem[i].itemStatus
                }
                

                await SubscriptionPlaneItem.update({_id:request.body.planItem[i].planItemId,planId:request.body.planId},{$set:dataToSave});
    
            }


        }

      
       
       
        let criteria={
            isDeleted:false
        }

        let findSubscriptionPlane=await SubscriptionPlane.aggregate([
                                                            {$match:criteria},      
                                                            { $lookup:
                                                                {
                                                    
                                                                from:'subscriptionplanitems',
                                                                localField: '_id',
                                                                foreignField: 'planId',
                                                                as: 'planDetails'
                                                                }
                                                            },
                                                            {
                                                            $project:{
                                                                "_id" : 1, 
                                                                "isDeleted" :1, 
                                                                "created_at" : 1, 
                                                                "isActive" : 1, 
                                                                "perPeriod" : 1, 
                                                                "planAmount" :1, 
                                                                "planName" : 1, 
                                                                "__v" : 1,
                                                                planDetails:{$filter: {
                                                                input: "$planDetails",
                                                                as: "item",
                                                                cond: { $eq: [ "$$item.isDeleted", false ] }
                                                                }}
                                                            }}
       ]);

       return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESS,data:findSubscriptionPlane});



       
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error}); 
    }
}

exports.addSubscriptionPlanAndPlanItem=async(request,response)=>{
    try{
        console.log(request.body,'request data')
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('planName',AppConstraints.PLANE_NAME).notEmpty();
        request.checkBody('planItem',AppConstraints.PLANE_ITEM).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});


        if(request.body.planItem.length<=0){
            return response.status(400).json({success:0,msg:AppConstraints.ATLEAST_ONE_ITEM})
        }

        let findIfAlreadySubs=await SubscriptionPlane.findOne({planName:request.body.planName});
        if(findIfAlreadySubs)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ALREADY_SUBSCRIPTION_PLAN})


        console.log('request plane',request.body.planName)

        let subscriptionplane=new SubscriptionPlane();
        subscriptionplane.planName=request.body.planName;
        subscriptionplane.planAmount=request.body.planAmount||"";
        subscriptionplane.perPeriod=request.body.perPeriod||"";
        let saveSubscription=await subscriptionplane.save();

        for(let i=0;i<request.body.planItem.length;i++){

            let planItem=new SubscriptionPlaneItem();
            planItem.planId=saveSubscription._id;
            planItem.itemQwery=request.body.planItem[i].itemQwery;
            planItem.itemStatus=request.body.planItem[i].itemStatus;
            await planItem.save();

        }
       
       
        let criteria={
            isDeleted:false
        }

        let findSubscriptionPlane=await SubscriptionPlane.aggregate([
                                                            {$match:criteria},      
                                                            { $lookup:
                                                                {
                                                    
                                                                from:'subscriptionplanitems',
                                                                localField: '_id',
                                                                foreignField: 'planId',
                                                                as: 'planDetails'
                                                                }
                                                            },
                                                            {
                                                            $project:{
                                                                "_id" : 1, 
                                                                "isDeleted" :1, 
                                                                "created_at" : 1, 
                                                                "isActive" : 1, 
                                                                "perPeriod" : 1, 
                                                                "planAmount" :1, 
                                                                "planName" : 1, 
                                                                "__v" : 1,
                                                                planDetails:{$filter: {
                                                                input: "$planDetails",
                                                                as: "item",
                                                                cond: { $eq: [ "$$item.isDeleted", false ] }
                                                                }}
                                                            }}
       ]);

       return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESS,data:findSubscriptionPlane});



       
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error}); 
    }
}

exports.planItemDataListing=async(request,response)=>{
    try{
        console.log(request.body,'request data')
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkQuery('planId',AppConstraints.PLANE_NAME).notEmpty().isMongoId();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});

        let data=await SubscriptionPlaneItem.find({planId:request.query.planId,isDeleted:false});
        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESS,data:data});
       
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error}); 
    }
}



exports.reAssignedOrder=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        request.checkBody('bookingId',AppConstraints.BOOKING_ID).notEmpty();
        request.checkBody('bookingId',AppConstraints.BOOKING_ID_VALID).isMongoId();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});
        let findBookingData=await Bookings.findOne({_id:request.body.bookingId}).populate({path:'userId',select:{}});
        let findDeviceToken=await User.findOne({_id:findBookingData.driverId});
        if(!findDeviceToken.isAvailable)
        return response.status(200).json({success:0,statusCode:400,msg:AppConstraints.DRIVER_NOT_AVAILABLE})
        let criteria={
            recieverId:findBookingData.driverId,
            isRead:false
        }
        let findTotalUnreadCount=await NotificationData.count(criteria);
        let dataToPush={
            msg:AppConstraints.BOOKING_REASSIGNED,
            messageType:AppConstraints.APP_CONST_VALUE.REASSIGNED,
            userId:findBookingData.userId._id,
            bookingId:request.body.bookingId,
            count:findTotalUnreadCount+1
        }
        let newNotification=new NotificationData();
        newNotification.recieverId=findBookingData.driverId,
        newNotification.bookingId=request.body.bookingId;
        newNotification.msg=AppConstraints.BOOKING_REASSIGNED;
        newNotification.messageType=AppConstraints.APP_CONST_VALUE.REASSIGNED;
        let criteriaUser={
            recieverId:request.body.driverId,
            isRead:false
        }
        await Promise.all([
            Bookings.update({_id:request.body.bookingId},
                {$set:{status:AppConstraints.APP_CONST_VALUE.REASSIGNED,
                        reAssignedCount:findBookingData.reAssignedCount+1,assignedTime:new Date().getTime()}}),
             pushNotification.sendPush(findDeviceToken.deviceToken,dataToPush),
             newNotification.save()
        ]);
        let findBooking=await Bookings.findOne({_id:request.body.bookingId});

        await SocketManager.emitAssignedBooking(findBooking);
        
        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESSFULLY_REASSIGNED})

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}



exports.assignSlotToDriver=async(request,response)=>{
    try{


        
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        request.checkBody('driverId',AppConstraints.DRIVER_ID).notEmpty().isMongoId();
        request.checkBody('bookingId',AppConstraints.BOOKING_ID).notEmpty().isMongoId();
        request.checkBody('slotTime',AppConstraints.TIME_SLOT).notEmpty();

        // let findDriverData=await User.findOne({_id:request.body.driverId})

        let criteria={
            recieverId:request.body.driverId,
            isRead:false
        }

        let findTotalUnreadCount=await NotificationData.count(criteria);

        let d=new Date();

        let dataToPush={
            msg:AppConstraints.RESHUDULED+' '+new Date(request.body.slotTime).getTime(),
            reshuduled:new Date(request.body.slotTime).getTime(),
            messageType:AppConstraints.APP_CONST_VALUE.SLOTE,
            userId:findBookingData.userId._id,
            bookingId:request.body.bookingId,
            count:findTotalUnreadCount+1
        }


        let newNotification=new NotificationData();
        newNotification.recieverId=request.body.driverId,
        reshuduled=new Date(request.body.slotTime).getTime(),
        newNotification.bookingId=request.body.bookingId;
        newNotification.msg=AppConstraints.RESHUDULED+' '+new Date(request.body.slotTime).getTime()
        newNotification.messageType=AppConstraints.APP_CONST_VALUE.SLOTE;
        
        await Promise.all([
            Bookings.update({_id:request.body.bookingId}, {$set:{timeSlot:new Date(parseInt(request.body.timeSlot)).getTime()}}),
            pushNotification.sendPush(findDeviceToken.deviceToken,dataToPush),
            newNotification.save()
        ]);



    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}







exports.viewDriverOrderHistory=async(request,response)=>{
    try{


        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        request.checkBody('driverId',AppConstraints.DRIVER_ID).notEmpty().isMongoId();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});
        let criteria={
            driverId:request.body.driverId,
            status:AppConstraints.APP_CONST_VALUE.COMPLETED
        }
        let findOrderOfDriver=await Bookings.find(criteria)
        return response.status(200).json({statusCode:200,msg:'success',success:1,data:findOrderOfDriver});



    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}



exports.sendEmailToAllUser=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('message',AppConstraints.MESSAGE_TO_USER).notEmpty()
        request.checkBody('subject',AppConstraints.SUBJECT).notEmpty()
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});


        let criteria={
            isBlocked:false,
            userType:AppConstraints.USER
        }

        let projection={
            email:1
        }


        let Email=[];
        let findAllUser=await User.find(criteria,projection);

        for(let i=0;i<findAllUser.length;i++){
            Email.push(findAllUser[i].email);
        }


        await UnivershalFunction.sendEmail(Email,request.body.message,request.body.subject);

        return response.status(200).json({success:1,msg:'email successfully sented to all user',statusCode:200})


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}




exports.sendPushNotificationToAllUser=async(request,response)=>{
    try{





        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        request.checkBody('message',AppConstraints.MESSAGE_TO_USER).notEmpty()
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});


        let criteria={
            isBlocked:false,
            userType:AppConstraints.USER
        }

        let projection={
            deviceToken:1
        }


        let deviceToken=[];

        let findAllUser=await User.find(criteria,projection);

        for(let i=0;i<findAllUser.length;i++){
            console.log(findAllUser[i].deviceToken)
            deviceToken.push(findAllUser[i].deviceToken);
        }


        let dataToPush={
            messageType:AppConstraints.APP_CONST_VALUE.ADMIN,
            msg:request.body.message
        }


        await pushNotification.sendPushToAllUser(deviceToken,dataToPush); 
        return response.status(200).json({success:1,msg:'notification successfully send to all user',statusCode:200})



    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.findPaymentPaidByCustomer=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        request.checkBody('userId',AppConstraints.USER_ID).notEmpty().isMongoId()
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});

        let criteria={
            userId:request.body.userId,
            status:AppConstraints.APP_CONST_VALUE.COMPLETED
        }

        let projection={
                        totalAmount:1
                    }

        let findData=await Bookings.find(criteria,projection);
        
        let totalPaidAmmount=0; 

        for(let i=0;i<findData.length;i++){
            totalPaidAmmount+=parseFloat(findData[i].totalAmount)
        }

        return response.status(200).json({success:1,msg:'total ammount pad by customer',data:{totalAmmount:totalPaidAmmount}})


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}

exports.userRegisteredInOneYear=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});
    
        let criteria={
            userType:AppConstraints.USER,
            createDate:{$gte:new Date(new Date().setFullYear(new Date().getFullYear()-1))}
        }

        let projection={
            createDate:1
        }



        console.log(err,'error')

        //    let findUser=await User.find(criteria,projection);
        //    for(let i=0;i<12;i++){
        //         for(let j=0;j<findUser.length;j++){
        //             if(new Date(findUser[i].createDate).getMonth()==i){
        //                 totalUserInYear=totalUserInYear+1;
        //             }
        //         }
        //     }



        // let data=await User.aggregate([
        //     {$match:{}}
        // ]);



       




        let data=[];

        return response.status(200).json({success:1,msg:'success',data:data,statusCode:200});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.raisedIssueListing=async(request,response)=>{
    try{


        console.log(request.body,'==========================================================')

        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});



      



        let criteria={};
        if(request.body.fromDate && request.body.toDate && request.body.userType){
            criteria={
                userType:request.body.userType,
                issuesCreateDate:{$gte:new Date(parseInt(request.body.fromDate)),$lte:new Date(parseInt(request.body.toDate))}
            }
        }

        if(request.body.fromDate&&request.body.toDate){
            criteria={
                issuesCreateDate:{$gte:new Date(parseInt(request.body.fromDate)),$lte:new Date(parseInt(request.body.toDate))}
            }
        }
        if(request.body.fromDate && request.body.userType){
            criteria={
                userType:request.body.userType,
                issuesCreateDate:{$gte:new Date(parseInt(request.body.fromDate))}
            }
        }

        if(request.body.toDate && request.body.userType){
            criteria={
                userType:request.body.userType,
                issuesCreateDate:{$lte:new Date(parseInt(request.body.toDate))}
            }
        }

        if(request.body.toDate){
            criteria={
                issuesCreateDate:{$lte:new Date(parseInt(request.body.toDate))}
            }
        } 

        if(request.body.fromDate){
            criteria={
                issuesCreateDate:{$gte:new Date(parseInt(request.body.fromDate))}
            }
        } 

        if(request.body.userType){
            criteria={
                userType:request.body.userType
            }
        }
        
       

        let data=await Promise.all([
            Issue.find(criteria)
            .sort({"_id":-1})
            .populate({path:'userId',select:{}})
            .skip((parseInt(request.body.perPage)*parseInt(request.body.page))-parseInt(request.body.perPage))
            .limit(parseInt(request.body.perPage)),
            Issue.count(criteria)
        ]);


        console.log(data[1],'============////////////////////////=============')

        return response.status(200).json({success:1,statusCode:200,msg:'success',data:data[0],totaResult:data[1]});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}

exports.revenueGenerated=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});



    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}



exports.totalEarningAccordingToLaundry=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        request.checkQuery('laundryId',AppConstraints.LAUNDRY_ID).notEmpty().isMongoId()
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});
        let findTotalEarning=await Bookings.aggregate([
            {$match:{laundryId:ObjectId(request.query.laundryId),status:AppConstraints.APP_CONST_VALUE.COMPLETED}},
            {$group:{_id:"$laundryId",totalAmmount:{$sum:"$totalAmount"}}}
        ]);

        return response.status(200).json({success:1,msg:'success',statusCode:200,data:findTotalEarning});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.totalEarningAccordingToDriver=async(request,response)=>{
    try{

        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        request.checkQuery('driverId',AppConstraints.DRIVER_ID).notEmpty().isMongoId()
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});
        let findTotalEarning=await Bookings.aggregate([
            {$match:{driverId:ObjectId(request.query.driverId),status:AppConstraints.APP_CONST_VALUE.COMPLETED}},
            {$group:{_id:"$driverId",totalAmmount:{$sum:"$totalAmount"}}}
        ]);

        return response.status(200).json({success:1,msg:'success',statusCode:200,data:findTotalEarning});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.listOfAllDriverEarnings=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        let findTotalEarning=await Bookings.aggregate([
            {$match:{status:AppConstraints.APP_CONST_VALUE.COMPLETED}},
            {$group:{_id:"$driverId",totalAmmount:{$sum:"$totalAmount"}}},
            {$lookup:{
                $lookup:
                {
                from: "users",
                localField : "driverId",
                foreignField : "_id",
                as: "userData"
                }
            }}
        ]);

        return response.status(200).json({success:1,msg:'success',statusCode:200,data:findTotalEarning});


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.trackStatusOfOrder=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        console.log(request.body);
        let data=[];
        return response.status(200).json({success:1,msg:'success',statusCode:200,data:data})
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.yearlyRevenueData=async(request,response)=>{
    try{


        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});

        let criteria={
            status:AppConstraints.APP_CONST_VALUE.COMPLETED
        }

        let projection={
            createDate:1,
            totalAmount:1
        }

        let prifitData=await Bookings.find(criteria,projection);
       

        let dataToSend=[];

        for(let j=0;j<12;j++){
            let Amount=0;
            for(let i=0;i<prifitData.length;i++){
                let d=new Date(prifitData[i].createDate);
                if(d.getMonth()==j){
                    Amount+=parseFloat(prifitData[i].totalAmount);
                  }
               }
            dataToSend.push({"month":j+1,"amount":Amount});
        }

        return response.status(200).json({success:1,data:dataToSend,success:1,msg:'success'});
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}



exports.yearlyAddedUserRevenue=async(request,response)=>{
    try{

    }catch(err){

    }
}

exports.serviceItemListingToAdmin=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        request.checkQuery('serviceId',AppConstraints.SERVICE_ID).notEmpty().isMongoId()
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0 , msg: errors[0].msg, error:errors});

        let criteria={}
     
        if(request.query.status=='ACTIVE'){
            criteria={
                serviceId:request.query.serviceId,
                isDeleted:false
            }
        }else if(request.query.status=='DELETED'){
            criteria={
                serviceId:request.query.serviceId,
                isDeleted:true
            }
        }else{
            criteria={
                serviceId:request.query.serviceId
            }
        }

           
        

        let findServiceItems=await serviceItem.find(criteria);

        return response.status(200).json({success:1,msg:'Success',data:findServiceItems,statusCode:200});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.editOrDeletePromoCode=async(request,response)=>{
    try{



        console.log(request.body,'')

        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        request.checkBody('promoCodeId',AppConstraints.PROMO_CODE_ID).notEmpty().isMongoId()
        request.checkBody('status',AppConstraints.STATUS).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});

        if(request.body.status=='EDIT'){
            let dataToSet={};

            if(request.body.promoCode){
                 let ifAlreadyPromos=await PromoCode.findOne({promoCode:request.body.promoCode});
                 if(ifAlreadyPromos){
                     if(ifAlreadyPromos._id==request.body.promoCodeId){
                         dataToSet['promoCode']=request.body.promoCode
                     }else{
                         return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ALREADY_PROMO});
                     }
                 }else{
                     dataToSet['promoCode']=request.body.promoCode
                 }
                 
             }
             
     


             


     
           
             if(request.body.expiryDate){
                 let d1 = new Date();
                 let d2 = new Date(request.body.expiryDate)
         
                 if(d2.getTime()>d1.getTime()){
                     return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.EXPIRY_DATE_VALID})
                 }
                 dataToSet['expiryDate']=request.body.expiryDate
     
             }




             if(request.body.startDate){
                let d1 = new Date();
                let d2 = new Date(request.body.startDate)
        
                // if(d2.getTime()>d1.getTime()){
                //     return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.EXPIRY_DATE_VALID})
                // }



                dataToSet['startDate']=request.body.startDate
    
            }
            
     
             if(request.body.discount){
                 if(parseFloat(request.body.discount)>100){
                     return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.DISCOUNT_NOT_MORE_100})
                 }
                 dataToSet['discount']=parseFloat(request.body.discount);
     
             }
     
     
             if(request.body.message){
                 dataToSet['message']=request.body.message
             }
           
     
             await PromoCode.update({_id:request.body.promoCodeId},{$set:dataToSet});
     





             let findUserTokens=await User.find({isBlocked:false,userType:AppConstraints.USER}).select({deviceToken:1});

             let allTokens=await findUserTokens.map((val)=>{
                 let token=val.deviceToken;
                 return token;
             });
     
     
             let dataToPush={};
     
             dataToPush.msg=request.body.message;
             dataToPush.promocode=request.body.promocode;
             dataToPush.messageType=AppConstraints.APP_CONST_VALUE.PROMO;
             dataToPush.msg=request.body.message;
             dataToPush.promocodeId=request.body.promoCodeId;
     
           
             
             await pushNotification.sendPushToAllUser(allTokens,dataToPush);









     
             let findPromocode=await PromoCode.findOne({_id:request.body.promoCodeId});
     
             return response.status(200).json({success:1,msg:'success',data:findPromocode,statusCode:200});
        }else if(request.body.status=='DELETE'){


            console.log(request.body.status,'===========================status data==================================')

            await PromoCode.update({_id:request.body.promoCodeId},{$set:{isDeleted:true}});
            return response.status(200).json({success:1,msg:'Successfully deleted',statusCode:200});
        }
        
        else{
            return response.status(400).json({success:0,msg:'Invalid status ',statusCode:400});
        }
        

    }catch(err){
        console.log(err,'===============================error data =====================================================================')
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});
    }
}


exports.createCoupon = async (request,response) => {
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});


        request.checkBody('couponCode',AppConstraints.PROMO_CODE).notEmpty();
        request.checkBody('expiryDate',AppConstraints.EXPIRY_DATE).notEmpty();
        request.checkBody('startDate',AppConstraints.START_DATE).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});


        let ifAlreadyCoupon=await coupon.findOne({couponCode:request.body.couponCode});


        if(ifAlreadyCoupon)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ALREADY_PROMO});

        let d1 = new Date();
        let d2 = new Date(request.body.expiryDate)

        if(d2.getTime()>d1.getTime()){
            return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.EXPIRY_DATE_VALID})
        }

        let startDate=new Date(request.body.startDate)

        // if(startDate.getTime()<d1.getTime()){
        //     return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.START_DATE_LESSER})
        // }

        let c=new coupon();

        c.couponCode=request.body.couponCode;
        c.expiryDate=new Date(parseInt(request.body.expiryDate)).getTime();
        c.startDate=new Date(parseInt(request.body.startDate)).getTime();



        await c.save();

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.PROMO_CODE_SUCCESS});            


    }
    catch(err){
        console.log(err);
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});       
    }
}



exports.createSlots=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        request.checkBody('slotTime',AppConstraints.SLOT_TIME).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});

        let slot=new slots();
        slot.slotTime=request.body.slotTime;
        slot.timing=request.body.timing;
        let saveSlot=await slot.save();

        return response.status(200).json({success:1,msg:'success',statusCode:200})

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error});       
    }
}


exports.versionUpdate = async (request,response) =>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.validateAdminAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED_ADMIN});
        request.checkBody("version",AppConstraints.VERSION).notEmpty();
        request.checkBody("app_type",AppConstraints.APP_TYPE).notEmpty();
        request.checkBody("platform",AppConstraints.PLATFORM).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});
        let versionAlredyExists = await version.findOne({version:request.body.version,app_type:request.body.app_type,platform:request.body.platform});
        if(versionAlredyExists){
            return response.status(400).json({statusCode:400,msg:"Version already exists",success:0});
        }else{

            let vrsn = new version();
            vrsn.version = request.body.version;
            vrsn.app_type = request.body.app_type;
            vrsn.platform = request.body.platform;
            await vrsn.save();
            console.log("Version new version added");
            return response.status(200).json({statusCode:200,msg:"New version added",success:1});

        }

          
    }
    catch(err){
        console.log(err);
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message.error}); 
    }
}


