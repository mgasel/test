const async=require('async');
const AppConstraints=require('../../config/appConstraints.js');
const User=require('../models/User.js');
const Forgot=require('../models/Forgot.js');
const Service=require('../models/Services.js');
const jwt = require('jsonwebtoken');
const ObjectId = require('mongodb').ObjectID;
const validator = require("email-validator");
const geodist=require('geodist');
const md5=require('md5');
const Laundry=require('../models/Laundry.js');
const UnivershalFunction=require('../UnivershalFunctions/Univershalfunctions.js');
const NodeGeocoder = require('node-geocoder');
const serviceItem=require('../models/serviceItems.js');
const SubscriptionPlane=require('../models/SubscriptionsPlan.js');
const SubscriptionPlaneItem=require('../models/SubcriptionPlaneItems.js');
const UsersPlan=require('../models/usersPlan.js');
const Bookings=require('../models/Bookings.js');
const Notifications=require('../models/notification.js');
const PromoCode=require('../models/promoCode.js');
const Review=require('../models/reviews.js');
const randomstring= require('randomstring');
const pushNotification=require('../LIB/pushNotification.js');
const twilio=require('twilio');
const client = new twilio(process.env.ACCOUNT_SID, process.env.ACCOUNT_AUTH_TOKEN);
const phoneverification=require('../models/phoneverification.js');
const Charge=require('../models/charge.js');
const Issue=require('../models/issue');
const NotificationData=require('../models/notification.js');
const userSubscriptionPlan=require('../models/UserSubscriptionPlane');
const coupon = require('../models/coupon.js')
const couponuser = require('../models/couponuser.js');
const log = require('../models/log.js');
const slot = require('../models/slots');
const version = require('../models/Version');
exports.sendOtp=async(request,response)=>{
    try{
        request.checkBody('phoneNumber',AppConstraints.PHONE_NUMBER).notEmpty();
        request.checkBody('callingCode',AppConstraints.CALLING_CODE).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});


        let criteriaEmail={
            email:request.body.email,
            userType:AppConstraints.USER
        }


        let criteriaPhoneNumber={
            phoneNumber:request.body.phoneNumber,
            userType:AppConstraints.USER
        }


        let ifEmailAlready=await User.findOne(criteriaEmail);
        if(ifEmailAlready)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.EMAIL_ALREADY});

        

        let ifPhoneAlready=await User.findOne(criteriaPhoneNumber);
        if(ifPhoneAlready)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.PHONE_ALREADY});



        let randomValue=new Date(new Date().getTime()+60000).getTime();

        var otpval=Math.floor(1000 + Math.random() * 9000);
        // let otpval = 4444;
        let otpDataVal="Your 3ndk otp code is "+otpval;

        console.log(otpDataVal,'otp value')

        let data={
            phoneNumber:request.body.callingCode+request.body.phoneNumber,
            message:otpDataVal
        }

        let sendOtp=await UnivershalFunction.unifonicMessage(data);

     

       

        console.log('otp data')


        let pv=new phoneverification();
        pv.callingCode=request.body.callingCode;
        pv.phoneNumber=request.body.phoneNumber;
        pv.otp=otpval;
        pv.expiryDate=randomValue;

        let saveOtp=await pv.save();

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.OTP_SEND_SUCCESSFULLY,data:saveOtp});


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}


exports.verifyOtp=async(request,response)=>{
    try{

        console.log(request.body,'request data')

        request.checkBody('otpId',AppConstraints.OTP_ID_REQUIRED).notEmpty().isMongoId();
        request.checkBody('otp',AppConstraints.OTP_REQUIRED).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});

        let criteria={
            _id:request.body.otpId,
            isActive:true,
            otp:request.body.otp
        }


        let findifExist=await phoneverification.findOne(criteria);

        if(!findifExist)
        return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.INVALID_OTP_CODE});

        let d=new Date();

        if(findifExist.expiryDate<d.getTime())
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.EXPIRED});
        await phoneverification.update(criteria,{$set:{isActive:false}});
        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.OTP_VERIFIED_SUCCESSFULLY})


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}


exports.resendOtp=async(request,response)=>{
    try{
        request.checkQuery('otpId',AppConstraints.PHONE_NUMBER).notEmpty().isMongoId();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});

        let findPhone=await phoneverification.findOne({_id:request.query.otpId});
        if(!findPhone)
        return response.status(200).json({success:0,statusCode:400,msg:AppConstraints.INVALID_OTP_ID});

        
        var otpval=Math.floor(1000 + Math.random() * 9000);
        
        let otpDataVal="Your 3ndk otp code is "+otpval;

        let data={
            phoneNumber:findPhone.callingCode+findPhone.phoneNumber,
            message:otpDataVal
        }

        let sendOtp=await UnivershalFunction.unifonicMessage(data);


        console.log(sendOtp,'========================sendOtp============================')

        // var message = await client.messages.create({
        //     body:otpDataVal,
        //     to:findPhone.callingCode+findPhone.phoneNumber, 
        //     from:process.env.PHONE_NUMBER
        // });

        // console.log(message,'message');
    
        // if(message.error)
        // return response.status(400).json({statusCode:400,success:0,msg:message.error,err:message.error});


        let randomValue=new Date(new Date().getTime()+60000).getTime();

        console.log(randomValue,'new expiry date');
    
        await phoneverification.update({_id:request.query.otpId},{$set:{otp:otpval,expiryDate:randomValue,isActive:true}});

        let getOtp=await phoneverification.findOne({_id:request.query.otpId});

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.OTP_SEND_SUCCESSFULLY,data:getOtp});


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.registerUser=async(request,response)=>{
    try{

        console.log(request.body,'request data');

        request.checkBody('name',AppConstraints.NAME).notEmpty();
        request.checkBody('email',AppConstraints.EMAIL_ADDRESS).notEmpty();
        request.checkBody('email',AppConstraints.VALID_EMAIL_ADDRESS).isEmail();
        request.checkBody('phoneNumber',AppConstraints.PHONE_NUMBER).notEmpty();

        request.checkBody('callingCode',AppConstraints.CALLING_CODE).notEmpty();

        request.checkBody('password',AppConstraints.PASSWORD).notEmpty();
        request.checkBody('deviceType',AppConstraints.DEVICE_TYPE).notEmpty();
        request.checkBody('deviceToken',AppConstraints.DEVICE_TOKEN).notEmpty();

        

        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});


        if(!(!isNaN(parseFloat(request.body.phoneNumber)) && isFinite(request.body.phoneNumber)))
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.PHONE_NUMERIC});


        let criteriaEmail={
            email:request.body.email,
            userType:AppConstraints.USER
        }


        let criteriaPhoneNumber={
            phoneNumber:request.body.phoneNumber,
            userType:AppConstraints.USER
        }


        let ifEmailAlready=await User.findOne(criteriaEmail);
        if(ifEmailAlready)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.EMAIL_ALREADY});

        let ifPhoneAlready=await User.findOne(criteriaPhoneNumber);
        if(ifPhoneAlready)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.PHONE_ALREADY});

        let randomValue=Math.floor(Date.now() / 1000) + (60 * 60);

        let rand = Math.floor((Math.random() * 1000) + 540000);

        let user = new User();

        user.name=request.body.name;
        user.email=request.body.email;
        user.phoneNumber=request.body.phoneNumber;
        user.callingCode=request.body.callingCode;
        user.password=await md5(request.body.password);
        user.countryName=request.body.countryName;
        user.accessToken=await randomstring.generate(150)
        user.deviceToken=request.body.deviceToken;
        user.deviceType=request.body.deviceType;
        user.emailVerificationcode=rand;
        user.userType=AppConstraints.USER;
        user.countryName=request.body.countryName;
        user.completePhoneNumber=request.body.callingCode+request.body.phoneNumber;
        
        if(request.body.coupon){
            const couponId = await coupon.findOne({couponCode:request.body.coupon});
            if(couponId){
                user.couponId = couponId._id;
                user.couponApplied = true;
            }else{
                return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.INVALID_COUPON});  
            }  
            
        }
        let token=await UnivershalFunction.GenerateToken({email:request.body.email,userType:AppConstraints.USER});
        
        let link=`${process.env.BASE_URL}verifyEmailPage?id=${rand}&accessToken=${token}`;

        let content="<br />"+AppConstraints.CLICK_BELOW+"<br /><a href="+link+">"+AppConstraints.CLICK_HERE+"</a>"



        let getDataSaved=await Promise.all([
            user.save(),
            UnivershalFunction.sendEmail(request.body.email,content,AppConstraints.REGISTRATIONS_MESSAGE)
        ]);

      
        // if(request.body.coupon){
        //     const couponId = await coupon.findOne({couponCode:request.body.coupon});
        //     console.log(couponId);
        //     if(couponId){
        //         let cu = new couponuser();
        //         cu.couponId=couponId._id;
        //         cu.userId = getDataSaved[0]._id;
        //         cu.expiryDate = couponId.expiryDate;
        //         cu.startDate = couponId.startDate;
        //         await cu.save();
        //     }else{
        //         return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.INVALID_COUPON});
        //     }
        // }
        

        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESS_GOTO_EMAIL,data:getDataSaved[0]});



    }catch(err){
        console.log(err);
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.verifyEmailPage=async(request,response)=>{
    try{
        return response.status(200).render('pages/verificationUser');
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.verifyUserEmail=async(request,response)=>{
    try{
        request.checkBody('id',AppConstraints.VERIFICATION_ID).notEmpty();
        request.checkBody('accessToken',AppConstraints.TOKEN).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});

        let decryptToken=await UnivershalFunction.DecryptToken(request.body.accessToken);

        if(!decryptToken)
        return response.status(200).json({statusCode:200,success:0,msg:AppConstraints.INVALID_TOKEN_KEY});


        let criteria={
            email:decryptToken.email,
            userType:decryptToken.userType
        }


        let findEmailCode=await User.findOne(criteria);

        if(findEmailCode && (findEmailCode.emailVerificationcode!==parseInt(request.body.id)))
        return response.status(200).json({statusCode:200,success:0,msg:AppConstraints.INVALID_VERIFICATION_ID});

        if(findEmailCode && (findEmailCode.emailVerificationcode===parseInt(request.body.id)) && findEmailCode.isEmailVerified)
        return response.status(200).json({statusCode:200,success:0,msg:AppConstraints.EMAIL_ALREADY_VERIFIED});

        let dataToSet={
            $set:{isEmailVerified:true}
        }

        await User.update(criteria,dataToSet);
        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.EMAIL_VERIFIED});


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.loginUser=async(request,response)=>{
    try{

        console.log(request.body,'request data in login');
        let getUserAllData={}
        let plansData=[]

        request.checkBody('password',AppConstraints.PASSWORD).notEmpty();
        request.checkBody('deviceType',AppConstraints.DEVICE_TYPE).notEmpty();
        request.checkBody('deviceToken',AppConstraints.DEVICE_TOKEN).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});



        if(validator.validate(request.body.email)){
            let CheckEmailExist=await User.findOne({email:request.body.email,userType:AppConstraints.USER});
            if(!CheckEmailExist)
            return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.EMAIL_NOT_REGISTERED});
            let findUser=await User.findOne({email:request.body.email,password:md5(request.body.password),userType:AppConstraints.USER});
            if(!findUser)
            return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.INVALID_EMAIL_PASSWORD});
    
    
            if(findUser && findUser.isBlocked)
            return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.SUSPENDED_ACCOUNT});
    
    
         
        
            let criteria={
                email:request.body.email,
                password:md5(request.body.password),
                userType:AppConstraints.USER
            }



            let randomValue=Math.floor(Date.now() / 1000) + (60 * 60);
   
            let token=await randomstring.generate(150);


            let dataToSet={
                $set:{
                      isOnline:true,
                      deviceType:request.body.deviceType,
                      deviceToken:request.body.deviceToken,
                      accessToken:token
                    }
            }
    
    
            await User.update(criteria,dataToSet);
    
    
    
            getUserAllData=await User.findOne(criteria)
                                    .select({licencePic:0,Profilepic:0})
                                    .populate({path:'subscryptinPlans',select:{}});

           
            
            plansData=await SubscriptionPlaneItem.find({isDeleted:false,planId:getUserAllData.subscryptinPlans});
           
            if(getUserAllData.isSubscriptiveUser)
            getUserAllData.planDetails=plansData;
        

           
            return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESSFULLY_LOG_IN,data:getUserAllData});
        
        }
        else if(!isNaN(parseFloat(request.body.email)) && isFinite(request.body.email)){


            

            let checkPhoneExist=await User.findOne({phoneNumber:request.body.email,userType:AppConstraints.USER});

            if(!checkPhoneExist)
            return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.PHONE_NOT_REGISTERED});

            let findUser=await User.findOne({phoneNumber:request.body.email,password:md5(request.body.password),userType:AppConstraints.USER});
            if(!findUser)
            return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.INVALID_PHONE_PASSWORD});
    
    
            if(findUser && findUser.isBlocked)
            return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.SUSPENDED_ACCOUNT});
    
    
          
        
            let criteria={
                phoneNumber:request.body.email,
                password:md5(request.body.password),
                userType:AppConstraints.USER
            }


              


            let randomValue=Math.floor(Date.now()/1000)+(60 * 60);

         
    
            let token=await randomstring.generate(150);

            let dataToSet={
                $set:{
                      isOnline:true,
                      deviceType:request.body.deviceType,
                      deviceToken:request.body.deviceToken,
                      accessToken:token
                }
            }
    
    
            await User.update(criteria,dataToSet);
    
    
    
            getUserAllData=await User.findOne(criteria)
                                     .select({licencePic:0,Profilepic:0})
                                     .populate({path:'subscryptinPlans',select:{}});


            plansData=await SubscriptionPlaneItem.find({isDeleted:false,planId:getUserAllData.subscryptinPlans});                     
     
            if(getUserAllData.isSubscriptiveUser)
            getUserAllData.planDetails=plansData

           
            return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESSFULLY_LOG_IN,data:getUserAllData});
        
        
        }
        else{
            return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.LOGIN_WITH_EMAIL_PHONE_NUMBER});
        }


     

      

    
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}


exports.sendForgotPasswordLink=async(request,response)=>{
    try{
            console.log(request.body,'request data')

            request.checkBody('forgotField',AppConstraints.FORGOT_FIELD).notEmpty();
            let errors = await request.validationErrors();
            if (errors)
            return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});
            if(validator.validate(request.body.forgotField)){

            let ifEmailExist=await User.findOne({email:request.body.forgotField,userType:AppConstraints.USER});
            if(!ifEmailExist)
            return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.NOT_A_VALID_FORGOT_EMAIL});


            let token=await UnivershalFunction.GenerateToken({email:request.body.forgotField,userType:AppConstraints.USER});
            let rand = Math.floor((Math.random() * 1000) + 540000);


            let link=`${process.env.BASE_URL}renderForgotPage?id=${rand}&accessToken=${token}`;


            let content="<br/>"+AppConstraints.CLICK_BELOW_FORGOT+"<br /><br /><br />"+link+"</a>"
    
            let forgot = new Forgot();
            forgot.email=request.body.forgotField;
            forgot.forgotCode=rand;
            forgot.userType=AppConstraints.USER;

            await Promise.all([
                forgot.save(),
                UnivershalFunction.sendEmail(request.body.forgotField,content,AppConstraints.FORGOT_SUBJECT)
            ]);
            

            return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.RESET_PASSWORD_LINK});
           
        
        }
        else if(!isNaN(parseFloat(request.body.forgotField)) && isFinite(request.body.forgotField)){
            ///////////////may twilio or ...fcm
        }
        else{
            return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.INVALID_FORGOT_FIELD});
        }
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.renderForgotPage=async(request,response)=>{
    try{
        return response.status(200).render('pages/forgotUser');
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.updateUserPassword=async(request,response)=>{
    try{

      

        request.checkBody('verificationcode',AppConstraints.VERIFICATION_CODE).notEmpty();
        request.checkBody('accessTokenkey',AppConstraints.TOKEN).notEmpty();
        request.checkBody('password',AppConstraints.PASSWORD).notEmpty();
        let errors =await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg,error:errors});
        let decryptToken=await UnivershalFunction.DecryptToken(request.body.accessTokenkey);
        if(!decryptToken)
        return response.status(200).json({statusCode:200,success:0, msg:AppConstraints.INVALID_TOKEN_KEY});
        let checkIfLinkActive=await Forgot.findOne({email:decryptToken.email,forgotCode:request.body.verificationcode,userType:decryptToken.userType});
        if(!checkIfLinkActive)
        return response.status(200).json({statusCode:200,success:0, msg:AppConstraints.INVALID_TOKEN_KEY_OR_CODE});
        if(checkIfLinkActive && !checkIfLinkActive.isActive)
        return response.status(200).json({statusCode:200,success:0, msg:AppConstraints.LINK_EXPIRED});

        await Promise.all([
            User.update({email:decryptToken.email,userType:decryptToken.userType},{$set:{password:md5(request.body.password)}}),
            Forgot.update({email:decryptToken.email,forgotCode:request.body.verificationcode,userType:decryptToken.userType},{$set:{isActive:false,isExpired:true}})
        ]);
        
        response.status(200).json({success:1,statusCode:200,msg:AppConstraints.PASSWORD_SUCCESSFULLY_UPDATED});
        
        
    }catch(err){
       return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}






exports.changePassword=async(request,response)=>{
    try{

            console.log(request.headers['authorization'])


            if(!request.headers['authorization'])
            return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
            let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
            if(!validateToken)
            return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});


            request.checkBody('newPassword',AppConstraints.NEW_PASSWORD).notEmpty();
            request.checkBody('currentPassword',AppConstraints.CURRENT_PASSWORD).notEmpty();
            
            let errors = await request.validationErrors();
            if (errors)
            return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg, error:errors});

            



            if(validateToken.password!==md5(request.body.currentPassword))
            return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.INVALID_CURRENT_PASSWORD})

          
            if(request.body.newPassword===request.body.currentPassword)
            return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.NEW_NOT_EQUAL_TO_CONFIRM});
            let randomValue=Math.floor(Date.now() / 1000) + (60 * 60);
            let criteria={
                _id:validateToken._id,
                userType:validateToken.userType
            }
            let dataToSet={
                $set:{password:md5(request.body.newPassword)}
            }
            await User.update(criteria,dataToSet);
            let UserData=await User.findOne(criteria);

            return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.CHANGED_PASSWORD,data:UserData});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.renderAllServices=async(request,response)=>{
    try{
      

        request.checkQuery('laundryId',AppConstraints.LAUNDRY_ID).notEmpty();      
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg, error:errors});

        let findServiceToLaundry=await Laundry.findOne({_id:request.query.laundryId},{services:1})


        let criteria={
            isDeleted:false,
            _id:{$in:findServiceToLaundry.services}
        }
        let getAllService=await Service.find(criteria);

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.SUCCESS,data:getAllService});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.renderLaundryList=async(request,response)=>{
    try{
        
 
        console.log(request.body,'request data');


        request.checkBody('lat',AppConstraints.USER_LAT).notEmpty();
        request.checkBody('long',AppConstraints.USER_LONG).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});

        let long = parseFloat(request.body.long);
        let lat = parseFloat(request.body.lat);
        let maxDistance=parseFloat(AppConstraints.APP_CONST_VALUE.MAX_DISTANCE);




        let criteria = {
            currentLocation: {
                $nearSphere: {
                    $geometry: {
                        type: "Point",
                        coordinates: [long, lat]
                    },
                    $maxDistance:maxDistance 
                },
            },
            isDeleted:false
        };



      


       let resultData=await Promise.all([
              Laundry.find(criteria),
              Laundry.count(criteria)
       ]);




        const promises = await resultData[0].map((myValue) => {
            
        return {
            _id:myValue._id,
            currentLocation:myValue.currentLocation, 
            __v:myValue.__v,
            isDeleted: myValue.isDeleted,
            created_at: myValue.created_at,
            isActive: myValue.isActive,
            laundryLong:myValue.laundryLong,
            laundryLat: myValue.laundryLat,
            laundryAddress:myValue.laundryAddress,
            laundryName:myValue.laundryName,
            distance:geodist({lat:myValue.laundryLat,lon:myValue.laundryLong},{lat:request.body.lat,lon: request.body.long})
          }


        });
       return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESS,data:promises,totalResult:resultData[1]});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}




exports.updateProfile=async(request,response)=>{
    try{


        console.log(request.body,'request data');

        let getUserAllData=[];

        console.log(request.headers['authorization'],'request header data');

        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});

      
      


        let dataToSet={};


        if(request.body.email){


            request.checkBody('email',AppConstraints.INVALID_EMAIL_ADDRESS).notEmpty().isEmail();
          
            let errors = await request.validationErrors();
            if (errors)
            return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});

           

            let findUser=await User.findOne({email:request.body.email,userType:AppConstraints.USER});




            if(!findUser){
                dataToSet['email']=request.body.email;
            }

            else {
                 if(""+validateToken._id===""+findUser._id){
                    dataToSet['email']=request.body.email;
                 }

                 else{
                     console.log('here');
                    return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.EMAIL_ALREADY});
                 }
               
            }

        }


        if(request.body.name){
            dataToSet['name']=request.body.name;
        }

        if(request.body.phoneNumber){
            let findUser=await User.findOne({phoneNumber:request.body.phoneNumber,userType:AppConstraints.USER});

            if(!findUser){
                dataToSet['phoneNumber']=request.body.phoneNumber;
            }

            else {


                if(""+validateToken._id===""+findUser._id){
                    dataToSet['phoneNumber']=request.body.phoneNumber;
                }

                else{
                    return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.PHONE_ALREADY});
                }



               
            }

        }



        if(request.body.callingCode){
            dataToSet['callingCode']=request.body.callingCode;
        }


        if(request.body.callingCode && request.body.phoneNumber){
            dataToSet['completePhoneNumber']=request.body.callingCode+request.body.phoneNumber;
        }


        if(request.body.gender){
            dataToSet['gender']=request.body.gender;
        }


        if(request.body.countryName){
            dataToSet['countryName']=request.body.countryName;
        }


        if(request.body.original){
            dataToSet['Profilepic.original']=request.body.original;
        }

        if(request.body.thumbnail){
            dataToSet['Profilepic.thumbnail']=request.body.thumbnail;
        }



        if(request.body.dateOfBirth){
            dataToSet['dateOfBirth']=request.body.dateOfBirth;
        }


       if(request.body.house_flat){
         dataToSet['house_flat']=request.body.house_flat;
       }
      
       
        if(request.body.landmark){
            dataToSet['landmark']=request.body.landmark;
        }
      
       
       
        
        if(request.body.location){
            dataToSet['location']=request.body.location;
        }
       
       
        if(request.body.lat){
            dataToSet['lat']=request.body.lat;
        }


        if(request.body.long){
            dataToSet['long']=request.body.long;
        }

        if(request.body.lat && request.body.long){
            dataToSet['currentLocation']=[parseFloat(request.body.long),parseFloat(request.body.lat)]
        }

        if(request.body.nationality){
            dataToSet['nationality']=request.body.nationality
        }



        let criteria={
            _id:validateToken._id,
            userType:validateToken.userType
        }

       

        await User.update(criteria,{$set:dataToSet});


        let findUserDataToSend=await User.findOne(criteria).select({licencePic:0,Profilepic:0}).populate({path:'subscryptinPlans',select:{}});

        let plansData=await SubscriptionPlaneItem.find({isDeleted:false,planId:findUserDataToSend.subscryptinPlans});

        if(findUserDataToSend.isSubscriptiveUser)
        findUserDataToSend.planDetails=plansData;

        console.log(findUserDataToSend.planDetails);

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.PROFILE_SUCCESSFULLY,data:findUserDataToSend});
       

     

       


    }catch(err){
        console.log(err,'error data');
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.logoutUser=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});


        let criteria={
            _id:validateToken._id,
            userType:AppConstraints.USER
        }

        let dataToSet={
            $set:{
                isOnline:false,
                accessToken:""
            }
        }

        await User.update(criteria,dataToSet);


        return response.status(200).json({
                                            success:1,
                                            statusCode:200,
                                            msg:AppConstraints.LOGOUT
                                        });


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.getServiceItemListing=async(request,response)=>{
    try{


        console.log(request.body,'request data in service item listing');

        request.checkBody('serviceId',AppConstraints.SERVICE_ID).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});

        let criteria={
            serviceId:request.body.serviceId,
            isDeleted:false
        }

        let findServiceItems=await serviceItem.find(criteria).populate({path:'serviceId',select:{serviceName:1,servicePic:1}});
        let findCharge=await Charge.find();
        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESS,data:findServiceItems,charge:findCharge});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.subscriptionPlaneListing=async(request,response)=>{
    try{
     



        let findSubscriptionList=await SubscriptionPlane.aggregate([
                                            {$match:{isDeleted:false}},      
                                            { $lookup:
                                                {
                                                from:'subscriptionplanitems',
                                                localField: '_id',
                                                foreignField: 'planId',
                                                as: 'planDetails'
                                                }
                                            },

                                            {
                                            $project:{
                                                "_id" : 1, 
                                                "isDeleted" :1,
                                                "isSelected":1, 
                                                "created_at" : 1, 
                                                "isActive" : 1, 
                                                "perPeriod" : 1, 
                                                "planAmount" :1, 
                                                "planName" : 1, 
                                                "__v" : 1,
                                                planDetails:{$filter: {
                                                input: "$planDetails",
                                                as: "item",
                                                cond: { $eq: [ "$$item.isDeleted", false ] }
                                                }}
                                            }}
                                        ])
      

        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESS,data:findSubscriptionList})

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}






exports.getSubscriptionPlaneItem=async(request,response)=>{
    try{
        request.checkBody('planId',AppConstraints.PLANE_ID).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});

        let criteria={
            planId:request.body.planId,
            isDeleted:false
        }

        let findplaneItem=await SubscriptionPlaneItem.find(criteria);


        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESS,data:findplaneItem});


    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.acceptUpgradeSubscriptionPlan=async(request,response)=>{
    try{




        console.log(request.body,'==============subscription plan data====================fghfhgh================')



        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});

        request.checkBody('planId',AppConstraints.PLANE_ID).notEmpty();
        // request.checkBody('planId',AppConstraints.PLANE_ID).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});
        let checkPlanId=await SubscriptionPlane.findOne({_id:request.body.planId});
        if(!checkPlanId)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.NOT_VALID_PLAN});
        
        await User.update({_id:validateToken._id},{$set:{subscryptinPlans:request.body.planId,isSubscriptiveUser:true}});


        let findUserData=await User.findOne({_id:validateToken._id})
                                   .select({licencePic:0,Profilepic:0})
                                   .populate({path:'subscryptinPlans',select:{}});


        let currentDate=new Date();                           


        let expiryDate=new Date(currentDate.setMonth(currentDate.getMonth()+1));

        console.log(expiryDate,'==============expiryDate========');
        
        let userplane=new userSubscriptionPlan();
        userplane.userId=validateToken._id;
        userplane.subscriptionPlanId=request.body.planId;
        userplane.perchageDate=new Date();
        userplane.expiryDate=expiryDate
        userplane.reciept=request.body.reciept;

        let dataToSave=await userplane.save();


        console.log(dataToSave,'dataToSave')

        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESSFULLY_UPGRADE,data:findUserData});  

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}











exports.myBookingList2=async(request,response)=>{
    try{


        console.log('bokings api',request.headers['authorization']);


        console.log(request.query,'query data')

        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});

      

        let criteria;

        if(request.query.status){
            if(request.query.status===AppConstraints.APP_CONST_VALUE.PENDING){
                criteria={
                    $and:[{userId:validateToken._id},
                    {$or:[{status:AppConstraints.APP_CONST_VALUE.PENDING},{status:AppConstraints.APP_CONST_VALUE.ASSIGNED},{status:AppConstraints.APP_CONST_VALUE.REASSIGNED}]}
                    ]
                };
            }
            if(request.query.status===AppConstraints.APP_CONST_VALUE.ACCEPTED){

                criteria={
                    $and:[{userId:validateToken._id},
                    {$or:[{status:AppConstraints.APP_CONST_VALUE.ACCEPTED},{status:AppConstraints.APP_CONST_VALUE.REASSIGNED},{status:AppConstraints.APP_CONST_VALUE.ASSIGNED}]}]
                    }

                
            }
            if(request.query.status===AppConstraints.APP_CONST_VALUE.COMPLETED){
                criteria.status=AppConstraints.APP_CONST_VALUE.COMPLETED
            }
        }
        let bookingsData=await Bookings.find(criteria)
                                       .sort({"_id":-1})
                                       .populate({path:'laundryId',select:{}});
                                      
           



        return response.status(200).json({success:1,msg:AppConstraints.SUCCESS,data:bookingsData});


        
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}








exports.myBookings=async(request,response)=>{
    try{


        console.log('bokings api',request.headers['authorization']);


        console.log(request.query,'query data')

        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});

     
       

        let criteria;

        // {status:AppConstraints.APP_CONST_VALUE.DELIVERED}

        if(request.body.status=='COMPLETED'){
             criteria={
                userId:validateToken._id,
               $or :[{status:AppConstraints.APP_CONST_VALUE.COMPLETED}]



    
            };
        }else{


            criteria={
               
                    userId:validateToken._id,
                    status:{$ne:AppConstraints.APP_CONST_VALUE.COMPLETED},
                    status:{$ne:AppConstraints.APP_CONST_VALUE.CANCELLED}
                
                
        }

    }
      
        

       





      

        let bookingsData=await Bookings.find(criteria)
                                       .sort({"_id":-1})
                                       .populate({path:'laundryId',select:{}});
                                   
                                      
           

                              


        return response.status(200).json({success:1,msg:AppConstraints.SUCCESS,data:bookingsData});


        
    }catch(err){
        console.log(err,'error')
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}









exports.renderNotificationList=async(request,response)=>{
    try{


        console.log('fsgdfg',request.headers)

        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});



        // console.log()


        let criteria={
            recieverId:validateToken._id,
            // isRead:false
        }

        let getAllNotification=await Notifications.find(criteria).sort({_id:-1});

        await Notifications.updateMany(criteria,{$set:{isRead:true}});


        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESS,data:getAllNotification});


    }catch(err){
        console.log(err)
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}









exports.createBookings=async(request,response)=>{
    try{
       
     console.log(request.body,"HELLO WORLD!");
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});
        request.checkBody('laundryId',AppConstraints.LAUNDRY_ID).notEmpty();
        request.checkBody('totalAmmount',AppConstraints.AMOUNT_REQUIRED).notEmpty();
        request.checkBody('isQuickService',AppConstraints.QUICK_SERVICE).notEmpty().isBoolean();
        request.checkBody('pickUpAddress',AppConstraints.PICKUP_ADDRESS).notEmpty();
        // request.checkBody('pickUpTime',AppConstraints.PICK_UP_TIME).notEmpty();
        request.checkBody('pickUpDate',AppConstraints.PICK_UP_DATE).notEmpty();
        request.checkBody('deliveryDate',AppConstraints.DELIVERED_DATE).notEmpty();
        request.checkBody('serviceCharge',AppConstraints.SERVICE_CHARGE).notEmpty();
        request.checkBody('deliveryCharge',AppConstraints.DELIVERY_CHARGE).notEmpty();
        request.checkBody('quickCharge',AppConstraints.QUICK_CHARGE).notEmpty();
        request.checkBody('bookingData',AppConstraints.BOOKING_DATA).notEmpty();

        request.checkBody('pickUpLat',AppConstraints.PICK_UP_LAT).notEmpty();
        request.checkBody('pickUpLong',AppConstraints.PICK_UP_LONG).notEmpty();
        request.checkBody('slotId',AppConstraints.SLOT_ID).isMongoId().notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});







        //////////////////////////////////////////////check if slot is open///////////////////////////////////
         
        let dateData = new Date(parseInt(request.body.pickUpDate));

        let slotCriteria={
            slotId:request.body.slotId,
            laundryId:request.body.laundryId,
            pickUpDate:{$gte:new Date(dateData.setUTCHours(0,0,0)).getTime(),$lte:new Date(dateData.setUTCHours(24,0,0)).getTime()}
        }


        let findBookingStatus=await Bookings.findOne(slotCriteria)

        console.log(slotCriteria,"SLOT CRITERIA");

        console.log(findBookingStatus,"findBookingStatus");


        if(findBookingStatus){
            return response.status(400).json({statusCode:400,success:0,msg:'Slot has filled'})
        }




        /////////////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////handel weekly//////////////////////////////////////////////
      
        



        let found = await log.findOne({userId:validateToken._id});
        console.log(found,"FOUND");
        let discount = 0;
        
        if(found && found.orderfree == true){
            if(found.freeOrderCount ==1){
                console.log("HERE1");
                await log.update({userId:validateToken._id},{$inc:{freeOrderCount:-1}});
                await log.update({userId:validateToken._id},{$set:{isActive:false}});
                discount = found.discount;
            } else if(found.freeOrderCount == 2){
                console.log("HERE2");
                await log.update({userId:validateToken._id},{$inc:{freeOrderCount:-1}});
                discount = found.discount;
            }else {
               
                if(validateToken.isSubscriptiveUser){
                    console.log("BAUGHT");
                    let userSubsciptionPlan={};
       
                    if(validateToken.subscryptinPlans)
                     userSubsciptionPlan=await SubscriptionPlane.findOne({_id:validateToken.subscryptinPlans});
            
                     console.log("ONE");

                    if(userSubsciptionPlan){
                        var current = new Date();     
                        var weekstart = current.getDate()-current.getDay() +1;    
                        var weekend = weekstart+6;
                        var monday = new Date(current.setDate(weekstart)).getTime();  
                        var sunday = new Date(current.setDate(weekend)).getTime();
                        console.log("TWO");

                        if(userSubsciptionPlan.planName=="Basic"){
                            console.log("THREE");

                            let criteria={
                                pickUpDate:{$gte:monday,$lte:sunday},
                                laundryId:request.body.laundryId,
                                userId:validateToken._id
                            }
                            let findBookingInThisWeek=await Bookings.count(criteria)
                            if(findBookingInThisWeek==1)
                            return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.ALREADY_BOOK_ONE_IN_THIS_WEEK})
                        }
            
                        if(userSubsciptionPlan.planName=="Plus"){
                            console.log("FOUR");

                            let criteria={
                                pickUpDate:{$gte:monday,$lte:sunday},
                                laundryId:request.body.laundryId,
                                userId:validateToken._id
                            }
                            let findBookingInThisWeek=await Bookings.count(criteria)
                            if(findBookingInThisWeek==2)
                            return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.ALREADY_BOOK_TWO_IN_THIS_WEEK})    
                        }
                    }
                }else{

                    return response.status(400).json({statusCode:400,success:0,msg:'YOUR FREE ORDERS ARE OVER'})
                }


            }
        }else{
            let userSubsciptionPlan={};
       
            if(validateToken.subscryptinPlans)
             userSubsciptionPlan=await SubscriptionPlane.findOne({_id:validateToken.subscryptinPlans});
    
            if(userSubsciptionPlan){
                var current = new Date();     
                var weekstart = current.getDate()-current.getDay() +1;    
                var weekend = weekstart+6;
                var monday = new Date(current.setDate(weekstart)).getTime();  
                var sunday = new Date(current.setDate(weekend)).getTime();
        
                if(userSubsciptionPlan.planName=="Basic"){
                    let criteria={
                        pickUpDate:{$gte:monday,$lte:sunday},
                        laundryId:request.body.laundryId,
                        userId:validateToken._id
                    }
                    let findBookingInThisWeek=await Bookings.count(criteria)
                    if(findBookingInThisWeek==1)
    
                    return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.ALREADY_BOOK_ONE_IN_THIS_WEEK})
                }
    
                if(userSubsciptionPlan.planName=="Plus"){
                    let criteria={
                        pickUpDate:{$gte:monday,$lte:sunday},
                        laundryId:request.body.laundryId,
                        userId:validateToken._id
                    }
                    let findBookingInThisWeek=await Bookings.count(criteria)
                    if(findBookingInThisWeek==2)
                    return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.ALREADY_BOOK_TWO_IN_THIS_WEEK})    
                }
            }
        }
        
               
















        
      


























       
            
        

console.log("discount",discount,"discount");

        let findUserPlan=await SubscriptionPlane.findOne({_id:validateToken.subscryptinPlans});

        if(findUserPlan && findUserPlan.planName=="Basic"){

            console.log('=========================inside basic plan==============================')


            if(parseFloat(request.body.totalAmmount)>100)
            return response.status(400).json({success:0,msg:AppConstraints.UPGRADE_PLANE_TO_PLACE_MORE_THAN_100,statusCode:400});
        }

        let findLaundryCity=await Laundry.findOne({_id:request.body.laundryId},{cityName:1})


        let criteria = {
            userType:AppConstraints.DRIVER,
            cityName:findLaundryCity.cityName,
            isAvailable: true,
            isOnline:true,
            laundryId:request.body.laundryId
        };


        let findDriver=await User.find(criteria).sort({load:1}).limit(1);


        let randomOrder=await randomstring.generate(6);
        let d = 0;
        if(request.body.promoCode )
       { console.log("INSIDE PROMOCODE THIS123")
           let disc = await PromoCode.findOne({promoCode:request.body.promoCode});
        if(disc){
            d = (request.body.totalAmmount*disc.discount)/100
            console.log(d,"disco");
        }
        }

        let booking=new Bookings();
        booking.userId=validateToken._id;
        booking.laundryId=request.body.laundryId;
        booking.totalAmmount=parseFloat(request.body.totalAmmount);
        booking.isQuickService=request.body.isQuickService;
        booking.pickUpDate=new Date(parseInt(request.body.pickUpDate)).getTime();
        booking.deliveryDate=new Date(parseInt(request.body.deliveryDate)).getTime();
        booking.serviceCharge=parseFloat(request.body.serviceCharge);
        booking.deliveryCharge=parseFloat(request.body.deliveryCharge);
        booking.deliveryCharge=parseFloat(request.body.deliveryCharge);
        booking.totalAmount=request.body.totalAmmount;
        booking.createDate=new Date().getTime();
        booking.paymentOption=request.body.paymentOption;
        booking.orderId=randomOrder
        booking.pickUpAddress=request.body.pickUpAddress;
        booking.pickUpLat=parseFloat(request.body.pickUpLat);
        booking.pickUpLong=parseFloat(request.body.pickUpLong);
        booking.pickUpLocation=[parseFloat(request.body.pickUpLong),parseFloat(request.body.pickUpLat)];
        booking.bookingData=(request.body.bookingData instanceof Object)?request.body.bookingData:JSON.parse(request.body.bookingData);
        booking.slotId=request.body.slotId;
        booking.discount=discount+d;

        let saveBooking;
        if(findDriver[0]&&findDriver[0]._id){

            booking.driverId=findDriver[0]._id;
            booking.status=AppConstraints.APP_CONST_VALUE.CONFIRMED;
            await User.update({_id:findDriver[0]._id},{$inc:{load:1}})

             saveBooking=await booking.save();



            let criteria={
                recieverId:findDriver[0]._id,
                isRead:false
            }

            let findTotalUnreadCount=await NotificationData.count(criteria);
            let d=new Date();
            let dataToPush={
                msg:AppConstraints.BOOKING_ASSIGNED,
                messageType:AppConstraints.APP_CONST_VALUE.ASSIGNED_ORDER,
                userId:validateToken._id,
                bookingId:saveBooking._id,
                count:findTotalUnreadCount+1
            }
            let newNotification=new NotificationData();
            newNotification.recieverId=findDriver[0]._id,
            newNotification.bookingId=saveBooking._id;
            newNotification.msg=AppConstraints.BOOKING_ASSIGNED;
            newNotification.messageType=AppConstraints.APP_CONST_VALUE.ASSIGNED_ORDER;
            newNotification.createDate=new Date().getTime()
            let criteriaUser={
                recieverId:validateToken._id,
                isRead:false
            };
            let findTotalUnreadCountUser=await NotificationData.count(criteriaUser);
            let dataToPushUser1 = {
                msg:AppConstraints.BOOKING_CONFIRMED,
                messageType:AppConstraints.APP_CONST_VALUE.CONFIRMED,
                driverId:findDriver[0]._id,
                bookingId:saveBooking._id,
                count:findTotalUnreadCountUser+1
            }
            let newNotificationUser1=new NotificationData();
            newNotificationUser1.recieverId=validateToken._id,
            newNotificationUser1.bookingId=saveBooking._id,
            newNotificationUser1.msg=AppConstraints.BOOKING_CONFIRMED;
            newNotificationUser1.messageType=AppConstraints.APP_CONST_VALUE.CONFIRMED;
            newNotificationUser1.createDate=new Date().getTime()
            let user = await User.findOne({_id:validateToken._id});
            let dataMessage={
                phoneNumber:validateToken.callingCode+validateToken.phoneNumber,
                message:AppConstraints.BOOKING_CONFIRMED+' your booking order number is '+randomOrder
            }
            let dataToUser = await Promise.all([
                UnivershalFunction.unifonicMessage(dataMessage),
                pushNotification.sendPush(findDriver[0].deviceToken,dataToPush),
                newNotification.save(),
                pushNotification.sendPushToUser(user.deviceToken,dataToPushUser1),   
                newNotificationUser1.save()
            ])

            console.log(dataToUser[0],'send message==================')

           
            

        }
        else{
            booking.status=AppConstraints.APP_CONST_VALUE.PENDING;
            saveBooking=await booking.save();
            let criteriaUser={
                recieverId:validateToken._id,
                isRead:false
            };
            let findTotalUnreadCountUser=await NotificationData.count(criteriaUser);
            let dataToPushUser1 = {
                msg:AppConstraints.BOOKING_CONFIRMED,
                messageType:AppConstraints.APP_CONST_VALUE.CONFIRMED,
                bookingId:saveBooking._id,
                count:findTotalUnreadCountUser+1
            }

            let newNotificationUser1=new NotificationData();
            newNotificationUser1.recieverId=validateToken._id,
            newNotificationUser1.bookingId=saveBooking._id,
            newNotificationUser1.msg=AppConstraints.BOOKING_CONFIRMED;
            newNotificationUser1.messageType=AppConstraints.APP_CONST_VALUE.CONFIRMED;
            newNotificationUser1.createDate=new Date().getTime()

            let dataToPushUser2 = {
                msg:AppConstraints.RESCHEDULE_ORDER,
                messageType:AppConstraints.APP_CONST_VALUE.ASK_RESCHEDULE,
                bookingId:saveBooking._id,
                count:findTotalUnreadCountUser+1
            }

            let newNotificationUser2=new NotificationData();
            newNotificationUser2.recieverId=validateToken._id,
            newNotificationUser2.bookingId=saveBooking._id,
            newNotificationUser2.msg=AppConstraints.RESCHEDULE_ORDER;
            newNotificationUser2.messageType=AppConstraints.APP_CONST_VALUE.ASK_RESCHEDULE;
            newNotificationUser2.createDate=new Date().getTime()
            let user = await User.findOne({_id:validateToken._id});
            let dataMessage={
                phoneNumber:validateToken.callingCode+validateToken.phoneNumber,
                message:AppConstraints.BOOKING_CONFIRMED+' your booking order number is '+randomOrder
            }
            let dataToUser=await Promise.all([
                UnivershalFunction.unifonicMessage(dataMessage),
                pushNotification.sendPushToUser(user.deviceToken,dataToPushUser1),   
                newNotificationUser1.save(),
                pushNotification.sendPushToUser(user.deviceToken,dataToPushUser2),
                newNotificationUser2.save()
            ]);


            // console.log(dataToUser[0],'==================send unifonic message============================')

            await UnivershalFunction.sendEmail(process.env.EMAIL_ADDRESS,AppConstraints.NEW_ORDER_PLACE,AppConstraints.NODRIVERFOUND_ONLINE)
        }
        

       
       
        if(request.body.promoCode){
            
            await PromoCode.update({promoCode:request.body.promoCode},{$addToSet:{usedBy:validateToken._id}});
        }





        

        let bookingsData=await Bookings.findOne({_id:saveBooking._id})
                                        .populate({path:'laundryId',select:{}});


        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.BOOKING_CREATED,data:bookingsData});
    }catch(err){
        console.log(err,'error data')
    return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.raisAnIssueBYUser=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});
        request.checkBody('issue',AppConstraints.ISSUE).notEmpty();
        request.checkBody('issueType',AppConstraints.ISSUE_TYPE).notEmpty();
        // request.checkBody('original',AppConstraints.ORIGINAL).notEmpty();
        // request.checkBody('thumbnail',AppConstraints.THUMBNAIL).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});
        let content='<br /> '+validateToken.name +" with email address "+validateToken.email+" has raise isuue type "+request.body.issueType+"<br />"+request.body.issue;
        await UnivershalFunction.sendEmailToAdmin(content,AppConstraints.ISSUE_BY_USER);
        console.log(request.query.issue,'issues===============')
        let issueData=new Issue();
        issueData.userId=validateToken._id;
        issueData.issue=request.body.issue;
        issueData.issueType=request.body.issueType;
        issueData.userType=AppConstraints.USER;
        if(request.body.original){
            issueData.imageUrl['original']=request.body.original;
        }
        if(request.body.thumbnail){
            issueData.imageUrl['thumbnail']=request.body.thumbnail;
        }
        await issueData.save();

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.ISSUE_CREATED_SUCCESS});
    }catch(err){
        console.log(err,'error');
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}




exports.createAReview=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});
        request.checkBody('bookingId',AppConstraints.BOOKING_ID).notEmpty();
        request.checkBody('overAllExperienceRating',AppConstraints.OVER_ALL_EXPERIENCE).notEmpty()
        request.checkBody('laundryServiceRating',AppConstraints.LAUNDRY_SERVICE).notEmpty();
        request.checkBody('driverRating',AppConstraints.DRIVER_REVIEW).notEmpty();
        request.checkBody('description',AppConstraints.RATING_DESCRIPTION).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg:errors[0].msg,error:errors});


        let forDriverId = await Bookings.findOne({_id:request.body.bookingId})
        console.log(forDriverId.driverId);


        let findIfAlreadyReviewed=await Review.findOne({userId:validateToken._id})
        if(findIfAlreadyReviewed){
            let dataToUpdate={};
            if(request.body.bookingId){
                dataToUpdate['driverId']=forDriverId.driverId;
            }
            if(request.body.overAllExperienceRating){
                dataToUpdate['overAllExperienceRating']=request.body.overAllExperienceRating;
            }
            if(request.body.laundryServiceRating){
                dataToUpdate['laundryServiceRating']=request.body.laundryServiceRating;
            }
            if(request.body.driverRating){
                dataToUpdate['driverRating']=request.body.driverRating;
            }
            if(request.body.description){
                dataToUpdate['description']=request.body.description;
            }
            await Review.update({userId:validateToken._id},{$set:dataToUpdate});


            let findReview=await Review.findOne({userId:validateToken._id});

            return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.REVIEW_UPDATED,data:findReview})
        }

       

        let review=new Review();
        review.userId=validateToken._id;
        review.driverId = request.body.driverId;
        review.overAllExperienceRating=request.body.overAllExperienceRating;
        review.laundryServiceRating=request.body.laundryServiceRating;
        review.driverRating=request.body.driverRating
        review.ratings=request.body.ratings;
        review.description=request.body.description;
        reviewcreateDate=new Date().getTime()
        let saveReviews=await review.save();

        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.REVIEW_CREATED,data:saveReviews});



    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.reviewListToUser=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});


        request.checkQuery('perPage',AppConstraints.PER_PAGE).notEmpty();
        request.checkQuery('page',AppConstraints.PAGE).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg, error:errors});

        let criteria={
            isDeleted:false
        };



     
        let findReviews=await Promise.all([
            Review.find(criteria)
            .sort({"_id":-1})
            .skip((parseInt(request.query.perPage)*parseInt(request.query.page)) - parseInt(request.query.perPage))
            .limit(parseInt(request.query.perPage))
            .populate({path:'userId',select:{name:1}}),
            Review.count(criteria)

        ]);


        console.log(findReviews[1],'total reviews count');

        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESS,data:findReviews[0],totalResult:findReviews[1]});



        

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}


exports.getPromocodeDetails=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});

        
        request.checkQuery('promoCode',AppConstraints.PROMO_CODE).notEmpty();
        let errors = await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg, error:errors});
      
        
        let isPromocodeValid=await PromoCode.findOne({promoCode:request.query.promoCode});
        if(!isPromocodeValid)
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.INVALID_PROMO_CODE});


       
        // let d1 = new Date();
        // let d2 = new Date(isPromocodeValid.expiryDate);


        // if(d1.getTime()>d2.getTime())
        // return response.status(400).json({success:0,statusCode:400,msg:AppConstraints.PROMO_EXPIRED});



        let criteria={
            promoCode:request.query.promoCode,
            usedBy:{$in:[validateToken._id]}
        };

        let findIfAlreadyUsed=await PromoCode.findOne(criteria);
        if(findIfAlreadyUsed)
        return response.status(200).json({success:0,statusCode:400,msg:AppConstraints.ALREADY_USED});
        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.SUCCESS,data:isPromocodeValid});
       
    }catch(err){
        console.log(err,'error in promo details');
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}


exports.checkLinkExpired=async(request,response)=>{
    try{

        console.log(request.body,'request data');


        request.checkBody('verificationcode',AppConstraints.VERIFICATION_CODE).notEmpty();
        request.checkBody('accessTokenkey',AppConstraints.TOKEN).notEmpty();
        let errors =await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg,error:errors});
        let decryptToken=await UnivershalFunction.DecryptToken(request.body.accessTokenkey);
        if(!decryptToken)
        return response.status(200).json({statusCode:200,success:0, msg:AppConstraints.INVALID_TOKEN_KEY});
        let checkIfLinkActive=await Forgot.findOne({
                                                    email:decryptToken.email,
                                                    forgotCode:request.body.verificationcode,
                                                    userType:decryptToken.userType
                                                   });
        
                                                   
                                                   


        if(!checkIfLinkActive)
        return response.status(200).json({statusCode:200,success:0, msg:AppConstraints.INVALID_TOKEN_KEY_OR_CODE});
        if(checkIfLinkActive && !checkIfLinkActive.isActive)
        return response.status(200).json({statusCode:200,success:0, msg:AppConstraints.LINK_EXPIRED});

        return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.SUCCESS});


    }catch(err){
        console.log(err,'error in promo details');
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}




exports.sendMessage=async(request,response)=>{
    try{


        let otpval=Math.floor(1000 + Math.random() * 9000);


        console.log('sghgdhgsjdg api get hitted')

        let data={
            phoneNumber:request.body.callingCode+request.body.phoneNumber,
            message:'Testing'
        }

        let sendOtp=await UnivershalFunction.unifonicMessage(data);

        console.log(sendOtp,'==========')

        return response.status(200).json({success:1,msg:sendOtp});




    }catch(err){

        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}


exports.orderDetailsForUser=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});

        request.checkQuery('bookingId',AppConstraints.BOOKING_ID).notEmpty();
        let errors =await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg,error:errors});


        let findOrderDetail=await Bookings.findOne({_id:request.query.bookingId})
                                          .populate({path:"laundryId",select:{}})
                                          .populate({path:"userId",select:{}});

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.SUCCESS,data:findOrderDetail});

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}


exports.getPromoCodeListing=async(request,response)=>{
    try{
       
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});

        let d=new Date().getTime();

        let criteria={
            usedBy:{$nin:[validateToken._id]},
            isDeleted:false,
            expiryDate:{$gte:d},
            startDate:{$lte:d}
        }
        
        let findPromocode=await PromoCode.find(criteria);

        console.log(findPromocode,'==========================findPromocode=====================================')

        return response.status(200).json({success:1,statusCode:200,msg:AppConstraints.SUCCESS,data:findPromocode})

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}



exports.userAvailability = async(request,response)=>{
    try{


        console.log(request.query,'===========================request data========================')

        console.log(request.headers,'ddhsdfghsgdhg')
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});
        request.checkQuery('bookingId',AppConstraints.BOOKING_ID).notEmpty().isMongoId();
        let errors =await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg,error:errors});
        let criteria={
            _id:request.query.bookingId
        }
        let findbookingData=await Bookings.findOne(criteria).populate({path:"driverId",select:{deviceToken:1}})

        if(!findbookingData)
        return response.status(400).json({success:0,msg:AppConstraints.INVALID_BOOKING_ID,statusCode:400})
        if(request.query.isAvailable==='true' || request.query.isAvailable===true || request.query.isAvailable===1||request.query.isAvailable==='1'){
            let criteriaDriver={
                recieverId:findbookingData.driverId._id,
                isRead:false
            }
            let findTotalUnreadCountDriver=await NotificationData.count(criteriaDriver);

            let dataToPushDriver={
                msg:AppConstraints.USER_ACCEPTED_ORDER,
                messageType:AppConstraints.APP_CONST_VALUE.ACCEPTED,
                userId:validateToken._id,
                bookingId:findbookingData._id,
                count:findTotalUnreadCountDriver
            }


            let newNotificationDriver=new NotificationData();
            newNotificationDriver.recieverId=findbookingData.driverId._id,
            newNotificationDriver.bookingId=findbookingData._id
            newNotificationDriver.msg=AppConstraints.USER_ACCEPTED_ORDER
            newNotificationDriver.messageType=AppConstraints.APP_CONST_VALUE.ACCEPTED
            newNotificationDriver.createDate=new Date().getTime()


            await Promise.all([
                 Bookings.update({_id:request.query.bookingId},{$set:{status:AppConstraints.APP_CONST_VALUE.ACCEPTED,approved:true}}),
                 newNotificationDriver.save(),
                 pushNotification.sendPush(findbookingData.driverId.deviceToken,dataToPushDriver)
            ])

            return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.MAKE_USER_SUCCESSFULLY_AVAILABLED});
        }

        else if(request.query.isAvailable==='false' || request.query.isAvailable===false||request.query.isAvailable===0||request.query.isAvailable==='0'){
            let dataToSet={
                status:AppConstraints.APP_CONST_VALUE.ASSIGNED,
                isRejected:true
            };
            await Promise.all([
                Bookings.update({_id:request.query.bookingId},{$set:dataToSet})
            ])
            return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.MAKE_USER_SUCCESSFULLY_UNABAILABLE});
        }

       

    }catch(err){
        console.log(err,'error data ==================')
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}


exports.getServiceToLaundry=async(request,response)=>{
    try{
        console.log(request.headers,'ddhsdfghsgdhg')
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});
        request.checkQuery('laundryId',AppConstraints.LAUNDRY_ID).notEmpty().isMongoId();
        let errors =await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg,error:errors});

        let findServices=await Laundry.findOne({_id:request.query.laundryId},{services:1});

        console.log(findServices,'findServices')

        let criteria={
            _id:{$in:findServices.services}
        }

        let findeServicesDetail=await Service.find(criteria);
        return response.status(200).json({statusCode:200,msg:AppConstraints.SUCCESS,success:1,data:findeServicesDetail})

    }catch(err){
        console.log(err,'error data ==================')
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}









exports.rechdedulebooking=async(request,response)=>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});
        request.checkBody('bookingId',AppConstraints.BOOKING_ID).notEmpty();
        request.checkBody('status',AppConstraints.RESCHEDULE_VALUE).notEmpty();
        let errors =await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg,error:errors});

        if(request.body.status === 'RESCHEDULE'){   

            let findAlreadyRescheduled =  await Bookings.findOne({_id:request.body.bookingId,isRescheduledBookingByUser:true})
            if(findAlreadyRescheduled)
            return response.status(400).json({status:400,success:0,msg:AppConstraints.ALREADY_RESCHEDULED})
           

            let newDataShift=new Date().getTime()
            await Bookings.update({_id:request.body.bookingId},{$inc:{pickUpDate:86400000}});
            await Bookings.update({_id:request.body.bookingId},{$set:{isRescheduledBookingByUser:true}});
            await Bookings.update({_id:request.body.bookingId},{$inc:{deliveryDate:86400000}});

            let b = await Bookings.findOne({_id:request.body.bookingId});

            let criteria={
                recieverId:b.driverId,
                isRead:false
            }

            let findTotalUnreadCount=await NotificationData.count(criteria);

            let d=new Date();
            let dataToPush={
                msg:AppConstraints.BOOKING_RESCHEDULED,
                messageType:AppConstraints.APP_CONST_VALUE.RESCHEDULED,
                userId:validateToken._id,
                bookingId:b._id,
                count:findTotalUnreadCount+1
            }
    
    
            let newNotification=new NotificationData();
            newNotification.recieverId=b.bookingId,
            newNotification.bookingId=b._id;
            newNotification.msg=AppConstraints.BOOKING_RESCHEDULED;
            newNotification.messageType=AppConstraints.APP_CONST_VALUE.RESCHEDULED;
            newNotification.createDate=new Date().getTime()
            let driver = await User.findOne({_id:b.driverId});

            let criteriaUser={
                recieverId:validateToken._id,
                isRead:false
            };

            let findTotalUnreadCountUser=await NotificationData.count(criteriaUser);
            let dataToPushUser = {
                msg:AppConstraints.RESCHEDULE_CONFIRMED,
                messageType:AppConstraints.APP_CONST_VALUE.RESCHEDULE,
                driverId:b.driverId,
                bookingId:b._id,
                count:findTotalUnreadCountUser+1
            }

            let newNotificationUser=new NotificationData();
            newNotificationUser.recieverId=validateToken._id,
            newNotificationUser.bookingId=b._id;
            newNotification.createDate=new Date().getTime()
            newNotificationUser.msg=AppConstraints.RESCHEDULE_CONFIRMED;
            newNotificationUser.messageType=AppConstraints.APP_CONST_VALUE.RESCHEDULE;

            await Promise.all([
                pushNotification.sendPush(driver.deviceToken,dataToPush),
                newNotification.save(),
                pushNotification.sendPushToUser(validateToken.deviceToken,dataToPushUser),
                newNotificationUser.save()
            ])


            return response.status(200).json({statusCode:200,msg:AppConstraints.SUCCESSESSFULLY_RESCHEDULED,success:1})
        }
        else if(request.body.status === 'CANCEL'){
            let alreadyPicked = await Bookings.findOne({_id:request.body.bookingId,isPickedUp:true});
            if(alreadyPicked){
            return response.status(400).json({status:400,msg:AppConstraints.ALREADY_PICKED,statusCode:400})
            }

            let findIforderAlreadyCancelled=await Bookings.findOne({_id:request.body.bookingId,status:AppConstraints.APP_CONST_VALUE.CANCELLED})

            if(findIforderAlreadyCancelled)
            return response.status(400).json({status:400,msg:AppConstraints.ORDER_ALREADY_CANCELLED,statusCode:400})
           
            let findBookingData=await Bookings.findOne({_id:request.body.bookingId}).populate({path:'driverId',select:{}})
            if(findBookingData && findBookingData.driverId){
                let findTotalUnreadCountUser=await NotificationData.count({driverId:findBookingData.driverId._id});
                let dataToPushUser = {
                    msg:AppConstraints.BOOKING_CANELLED,
                    messageType:AppConstraints.APP_CONST_VALUE.CANCELLED,
                    driverId:findBookingData.driverId._id,
                    bookingId:findBookingData._id,
                    count:findTotalUnreadCountUser+1

                }
    
    
    
                let newNotificationUser=new NotificationData();
                newNotificationUser.recieverId=findBookingData.driverId._id,
                newNotificationUser.bookingId=findBookingData._id,
                newNotificationUser.msg=AppConstraints.BOOKING_CANELLED;
                newNotificationUser.messageType=AppConstraints.APP_CONST_VALUE.CANCELLED;
                newNotificationUser.createDate=new Date().getTime()
    
                await Promise.all([
                    User.update({_id:findBookingData.driverId._id},{$inc:{load:-1}}),
                    Bookings.update({_id:request.body.bookingId},{$set:{status:AppConstraints.APP_CONST_VALUE.CANCELLED}}),
                    newNotificationUser.save(),
                    pushNotification.sendPush(findBookingData.driverId.deviceToken,dataToPushUser)
                ]);
            }else{
               
                await Promise.all([
                  
                    Bookings.update({_id:request.body.bookingId},{$set:{status:AppConstraints.APP_CONST_VALUE.CANCELLED}})                   
                ]);
            }
    
            
           

            
            return response.status(200).json({statusCode:200,success:1,msg:AppConstraints.ORDER_CANELLED_SUCCESSFULLY})
        }
       

    }
    catch(err){
        console.log(err);
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}


exports.updateLaundryId=async (request,response)=>{
    try{


        console.log(request.body,'request data')

        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});
        
        request.checkBody('laundryId',AppConstraints.LAUNDRY_ID).notEmpty();
        let errors =await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg,error:errors});

        console.log(request.body.laundryId);
        await User.update({_id:validateToken._id},{$set:{laundryId:request.body.laundryId}});

        return response.status(200).json({statusCode:200,success:1,msg:"Laundry Update"})

    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}

exports.termsAndCondition=async(request,response)=>{
    try{
        return response.status(200).render('pages/termscondition');
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}


exports.privacyPolicy=async(request,response)=>{
    try{
        return response.status(200).render('pages/privacyPolicy');
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}


exports.choosePack = async (request,response)=>{
    try{
    if(!request.headers['authorization'])
    return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
    let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
    if(!validateToken)
    return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});
    request.checkBody('choice',AppConstraints.CHOICE).notEmpty();
    let errors =await request.validationErrors();
    if (errors)
    return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg,error:errors});

    let found = await log.findOne({userId:validateToken._id});

    if(found){
        if(found.isActive)
    return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.LOG_FOUND});
    }


    if(request.body.choice=="MONTHFREE"){

        const lg = new log();
        lg.userId = validateToken._id;
        lg.fromDate = new Date().getTime();
        lg.tillDate = new Date().getTime() + 2678400000;
        lg.monthfree = true;
        lg.planId = request.body.planId;
       let logdata = await lg.save();

       let checkPlanId=await SubscriptionPlane.findOne({_id:request.body.planId});
       if(!checkPlanId)
       return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.NOT_VALID_PLAN});
       

       let dataToSet={
        subscryptinPlans:request.body.planId,
        isSubscriptiveUser:true,
        packChoosen:true
       }

       await User.update({_id:validateToken._id},{$set:dataToSet});

       let currentDate=new Date();                           


       let expiryDate=new Date(currentDate.setMonth(currentDate.getMonth()+1));

       console.log(expiryDate,'==============expiryDate========');
       
       let userplane=new userSubscriptionPlan();
       userplane.userId=validateToken._id;
       userplane.subscriptionPlanId=request.body.planId;
       userplane.perchageDate=new Date();
       userplane.expiryDate=expiryDate
       userplane.reciept=request.body.reciept;

       let dataToSave=await userplane.save();


       console.log(dataToSave,'dataToSave')

       return response.status(200).json({statusCode:200,success:1,msg:"MONTH FREE",data:logdata})


    }else if(request.body.choice=="ORDERFREE"){
        const lg = new log();
        lg.userId = validateToken._id;
        lg.fromDate = new Date().getTime();
        lg.tillDate = new Date().getTime() + 2678400000;
        lg.orderfree = true;
        lg.freeOrderCount = 2;
        lg.discount = 100;
        let logdata = await lg.save();
        await User.findOneAndUpdate({_id:validateToken._id},{$set:{packChoosen:true}});
        return response.status(200).json({statusCode:200,success:1,msg:"ORDER FREE",data:logdata})

    }else{
    return response.status(400).json({status:400,success:0,msg:AppConstraints.INVALID_CHOICE})
    }
    }catch(err){
        console.log(err);
    return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }

}



exports.findLog = async (request,response) =>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});
        let errors =await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg,error:errors});

        let found = await log.findOne({userId:validateToken._id}).populate({path:'planId',select:{planName:1}});;
                if(found && found.isActive == true && found.orderfree == true ){
                    if(found.freeOrderCount >0){
                    return response.status(200).json({statusCode:200,success:1,msg:"LOG DATA",data:found})
                    }
                }else if(found && found.isActive == true && found.monthfree == true ){
                    return response.status(200).json({statusCode:200,success:1,msg:"LOG DATA",data:found})

                }else{
                return response.status(200).json({status:200,success:1,msg:AppConstraints.NOT_FOUND})
                }
            
       
    }
    catch(err){
        console.log(err)
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message}); 
    }
}

exports.getSlots = async (request,response) =>{
    try{
        if(!request.headers['authorization'])
        return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        if(!validateToken)
        return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});
        request.checkBody('laundryId',AppConstraints.LAUNDRY_ID).notEmpty();
        // request.checkBody('localTime',AppConstraints.LOCAL_TIME).notEmpty();
        request.checkBody('pickUpDate',AppConstraints.PICK_UP_DATE).notEmpty();
        
        let errors =await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg,error:errors});
        console.log(request.body.pickUpDate,"PICKUPDATE");
        let dateData = new Date(parseInt(request.body.pickUpDate));
        // let dateData=new Date();
        console.log(dateData,"DateData")
        let criteria = {
           laundryId:request.body.laundryId,
           pickUpDate:{$gte:new Date(dateData.setUTCHours(0,0,0)).getTime(),$lte:new Date(dateData.setUTCHours(24,0,0)).getTime()}
         
        }
        console.log(criteria,"criteria")

        let projection={
            pickUpDate:1,
            slotId:1
        }

        let findAllBooking=await Bookings.find(criteria,projection);

        // console.log(findAllBooking,'booking')

        let slotId=[]

        for(let i=0;i<findAllBooking.length;i++){

            console.log(findAllBooking[i].slotId,'sdghsgydugshgdj')

            slotId.push(""+findAllBooking[i].slotId);
        }

        console.log(slotId,'fdjfdjfjdfjd')

        let slotData = await slot.find();

        let dataToSend=[];







        for(let j=0;j<slotData.length;j++){
            let jsonToPush={}
            jsonToPush._id=slotData[j]._id;
            jsonToPush.slotTime=slotData[j].slotTime;
            jsonToPush.timing=slotData[j].timing;

        
            jsonToPush.isActive=true;

         

            console.log(slotData[j]._id,'slot===============================data');
            console.log(slotId,'slot data=================================================')

            if(slotId.indexOf(""+slotData[j]._id)>-1){
                jsonToPush.isActive=false;
                console.log(slotData[j]._id,'slot id ')
               
            }
           

            dataToSend.push(jsonToPush)

        }
        

        return response.status(200).json({success:1,msg:'success',statusCode:200,data:dataToSend})
    
        
    }
    catch(err){
    console.log(err)
    return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message}); 
    }
}


exports.verifyCoupon = async(request,response) =>{
    try{
        request.checkBody('coupon',AppConstraints.COUPON).notEmpty();
        let errors =await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg,error:errors});
        const couponId = await coupon.findOne({couponCode:request.body.coupon});
        if(!couponId){
            return response.status(200).json({statusCode:200,success:0,msg:'FALSE'});  
        }else{
            return response.status(200).json({statusCode:200,success:1,msg:"TRUE"})

        }  
    
    }
    catch(err){
    console.log(err)
    return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});       
    }
}

exports.aboutus=async(request,response)=>{
    try{
        return response.status(200).render('pages/aboutus');
    }catch(err){
        return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}

exports.versionChecker = async (request,response)=>{
    try{
        // if(!request.headers['authorization'])
        // return response.status(400).json({statusCode:400,success:0,msg:AppConstraints.ACCESS_TOKEN});
        // let validateToken=await UnivershalFunction.ValidateUserAccessToken(request.headers['authorization']);
        // if(!validateToken)
        // return response.status(401).json({statusCode:401,success:0,msg:AppConstraints.UNAUTHORIZED});
        request.checkBody('version',AppConstraints.VERSION).notEmpty();
        request.checkBody('app_type',AppConstraints.APP_TYPE).notEmpty();
        request.checkBody('platform',AppConstraints.PLATFORM).notEmpty();
        let errors =await request.validationErrors();
        if (errors)
        return response.status(400).json({statusCode:400,success:0,msg: errors[0].msg,error:errors});   
        
        let latestVersion = await version.find({app_type:request.body.app_type,platform:request.body.platform}).sort({version:-1}).limit(1);
        
        if(latestVersion[0].version>request.body.version){
            // let criteria={
            //     recieverId:validateToken._id,
            //     isRead:false
            // }
            // let findTotalUnreadCount=await NotificationData.count(criteria);

            // let dataToPush={
            //     msg:AppConstraints.UPDATE_APPLICATION,
            //     messageType:AppConstraints.APP_CONST_VALUE.UPDATE,
            //     count:findTotalUnreadCount
            // }
    
            // let newNotification=new NotificationData();
            // newNotification.recieverId=validateToken._id
            // newNotification.msg=AppConstraints.UPDATE_APPLICATION
            // newNotification.messageType=AppConstraints.APP_CONST_VALUE.UPDATE
            // newNotification.createDate=new Date().getTime()
    
            // await Promise.all([
            //     pushNotification.sendPushToUser(validateToken.deviceToken,dataToPush),
            //     newNotification.save()
            // ]);
            return response.status(200).json({success:0,statusCode:200});    
        }else{
            return response.status(200).json({success:1,statusCode:200});    
        }
    }
    catch(err){
    console.log(err);
    return response.status(500).json({statusCode:500,success:0,msg:err.message,err:err.message});
    }
}
