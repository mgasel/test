let mongoose=require('mongoose');
let Schema=mongoose.Schema;

let subscriptionPlan=Schema({

    planName:                       {   type:String,default:"",index:true  },

    planAmount:                     {   type:String, default:"" },
 
    perPeriod:                      {   type:String, default:"" },

    isActive:                       {   type:Boolean, default:true },
   
    created_at:                     {   type:Date,  default:Date.now },

    isDeleted:                      {   type:Boolean, default:false  },

    isSelected:                     {   type:String,default:false }
    
});


module.exports=mongoose.model('subscriptionPlan',subscriptionPlan);