let mongoose=require('mongoose');
let Schema=mongoose.Schema;

let slots=Schema({
    slotTime:{type:String,default:""},
    timing:{type:String,default:"",enum:["MORNING","EVENING"]}
});


module.exports=mongoose.model('slots',slots);