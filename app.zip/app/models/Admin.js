let mongoose=require('mongoose');
let Schema=mongoose.Schema;
let Admin=Schema({
    email:                              {  type:String,default:"",index:true },

    password:                           {  type:String,default:"" },

    accessToken:                        {  type:String,default:"",index:true},
    
    created_at:                         {  type:Date,default:Date.now }
});
module.exports=mongoose.model('AdminDetails',Admin);


